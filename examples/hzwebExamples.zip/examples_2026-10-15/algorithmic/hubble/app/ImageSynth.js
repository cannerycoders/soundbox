class ImageSynth
{
  constructor(app, himage, playhead) 
  {
    this.app = app;
    this.ascene = app.ascene;
    this.playhead = playhead; // must be before setHimage
    this.setHimage(himage);
       
    this.amplitude_scaling = 2; // ie square
    this.max_oscillator_amplitude = .4;
    this.lp_cutoff_min = 500; 
    this.lp_cutoff_max = 10000;
  }
    
  async Init(cfg = {Waveform: 0})
  {
    this.cfg = cfg;
    if (cfg._active == false)return;
        
    this.midiNumbers = this.app.GetHarmony(this.cfg._note_offset || 0);
    this.makeAmpFreqArrays();
        

    // HzWeb can't handle this.n_data_rows oscillator nodes.  
    // But perhaps it can handle a bunch of oscillator voices.
    let preset = {
      Waveform: cfg.Waveform ?? 0,
      VoiceMgr: {
        maxVoices: this.n_data_rows
      },
      Gain: 6 / this.n_data_rows
    };
    this.osc = await this.ascene.NewAnode("Hz.Osc", {preset});
    // We don't show because most params only affect new notes
    // and we have n sustained notes.
    // this.osc.Show(); 

    // debugger;
    this.filterNode = await this.ascene.NewAnode("Hz.Filter");
    await this.filterNode.LoadPreset({
      Type: 0, // lowpass
      Frequency: 750,
      Resonance: .8
    });
    this.filterNode.Show();
    
    this.ascene.Chain(this.osc, this.filterNode, this.app.reverbNode);

    this.UpdateOscillators(true);
  }
  
  Stop()
  {
    this.osc.SetParam("Gain", 0);
  }
    
  UpdateOscillators(init)
  {
    //oscillator data is always read right/left
    if (!this.cfg._active)return;
    let image_data_col = Math.floor(this.playhead.n_position * this.n_data_cols);
    image_data_col = this.app.Constrain(image_data_col, 0, this.n_data_cols - 1);
    for (let i = 0; i < this.n_data_rows; i++) 
    {
      // XXX: smoothing?
      // could set to actual time between data points?
      let amp = this.amplitudes[i][image_data_col];
      let freq = this.frequencies[i][image_data_col];
      let noteid = i;
      let when = 0;
      if (init)
      {
        // noteoff elsewhere
        // although the note isn't important (we set _frequency directly)
        // we select different (low) notes to avoid "stuck-key"
        this.osc.NoteOn(i, 1, when, null, noteid);
      }
      this.osc.NoteExpression("expression", amp, when, noteid);
      this.osc.NoteExpression("_frequency", freq, when, noteid);
    }
    this.himage.column_average = this.getColumnAverage(image_data_col);
    let cutoff = this.app.Remap(this.himage.column_average, 
                            0,  this.max_oscillator_amplitude, 
                            this.lp_cutoff_min, this.lp_cutoff_max);
    if (cutoff != this.lastCutoff)
    {
      // console.log(`new cutoff: ${cutoff}, ${this.himage.column_average}`);
      this.filterNode.SetParam("Frequency", cutoff);
      this.lastCutoff = cutoff;
    }
  }

  setHimage(himage) 
  {
    this.himage = himage;
    this.chooseOscillatorData();
    this.n_data_rows = Object.keys(this.oscillator_grey_data).length;
    this.n_data_cols  = this.oscillator_grey_data[0].length;
  }

  chooseOscillatorData()
  {
    //Sets the data that's fed to the oscillators based on the scan type and direction
    switch (this.playhead.playhead_type) 
    {
    case 'leftright':
      this.oscillator_grey_data = this.himage.LR_grey_data;
      this.oscillator_color_data = this.himage.LR_color_data;
      break;
    case 'updown':  
      this.oscillator_grey_data = this.himage.UD_grey_data;
      this.oscillator_color_data = this.himage.UD_color_data;
      break;
    case 'outin':
      this.oscillator_grey_data = this.himage.radial_grey_data;
      this.oscillator_color_data = this.himage.radial_color_data;
      break;
    case 'cwccw':
      this.oscillator_grey_data = this.himage.polar_grey_data;
      this.oscillator_color_data = this.himage.polar_color_data;
      break;
    }
  }
    
  makeAmpFreqArrays()
  {
    //create amplitues and frequencies based on the current pitch mapping
    this.amplitudes = [];
    this.frequencies = [];

    for (let row = 0; row < this.n_data_rows; row++) 
    {
      let amplitudeRow = [];
      let frequencyRow = [];
      for (let col = 0; col < this.n_data_cols; col++) 
      {
        let v = this.oscillator_grey_data[row][col] ** this.amplitude_scaling; 
        let amplitude = this.app.Remap(v, 
                                        0, 255 ** this.amplitude_scaling, 
                                        0, this.max_oscillator_amplitude);
        if (this.app.pitch_mapping == 'brightness') 
          v = this.oscillator_grey_data[row][col];
        else 
          if (this.app.pitch_mapping == 'color') 
            v = this.oscillator_color_data[row][col];
        let midiIndex = Math.floor(this.app.Remap(v,
                                        0, 255, 0, this.midiNumbers.length - 1));
        let frequency = Tonal.Midi.midiToFreq(this.midiNumbers[midiIndex]);
                amplitudeRow.push(amplitude);
                frequencyRow.push(frequency);
      }
      this.amplitudes.push(amplitudeRow);
      this.frequencies.push(frequencyRow);
    }
  }

  getColumnAverage(column) 
  {
    let sum = 0;
    for (let i = 0; i < this.amplitudes.length; i++)
      sum += this.amplitudes[i][column];
    let average = sum / this.amplitudes.length;
    return average;
  }

}
  
exports.ImageSynth = ImageSynth;
