const defaults = 
{
    crossing_time: 10, // measured in seconds
    crossing_time_min: 1,
    crossing_time_max: 90,
    
    direction_sign: 1, // Default direction sign
    playhead_type: "leftright", // Default playhead type
    
    line_alpha: 200, // Set the alpha value to 100 (out of 255)
};

class Playhead 
{
    constructor(app, himage) 
    {
        this.app = app;
        this.himage = himage;
        this.n_position = 0;
        this.crossing_time = defaults.crossing_time; //crossing time in seconds (the speed slider will change this)
        this.delta_n_position = 0; // measured in pct of width
        this.direction_sign = defaults.direction_sign;
        this.speed = 1;
        
        this.playhead_type = defaults.playhead_type;
    }
    
    SetSpeed(speed) 
    {
        this.speed = speed;
        // updateRate called on each increment
    }
    
    updateRate(speed)
    {
        if(this.app.framerate == 0) return false;
        if(this.himage.width == null) return false;
        
        // framerate is frames/second
        // crossing_time is seconds
        // 10 sec * 60 frame / sec = 600 frames
            
        let nframes = this.crossing_time*this.app.framerate / this.speed; 
        let pctPerFrame = 1 / nframes;
        if(pctPerFrame != this.delta_n_position)
        {
            this.delta_n_position = pctPerFrame;
            // console.log(`percentPerFrame ${pctPerFrame} (${nframes} @ ${this.app.framerate} fps)`);
        }
        return true;
    }

    incrementPosition() 
    {
        if(!this.updateRate()) return;
        
        this.n_position += this.direction_sign * this.delta_n_position;

        // Reset n_position if it gets too big
        if(this.n_position >= 1)
        {
            this.n_position = 0;
            // console.log("playhead wrap R");
        }
        else 
        if(this.n_position <= 0) 
        {
            this.n_position = 1;
            // console.log("playhead wrap L");
        }
    }

    reverse() 
    {
        this.direction_sign *= -1; 
    }

    draw() 
    {
        if(this.himage.width == null) return;
        
        // Draw the playhead based on the type
        this.canvas = this.app.canvas;
        if(this.canvas != this.app.canvas) 
        {
            this.canvas == this.app.canvas
            if(!this.canvas) return;
        }
        
        switch(this.playhead_type) 
        {
        case 'leftright':
            this.drawLinear();
            break;
        case 'updown':
            this.drawLinear();
            break;
        case 'outin':
            this.drawRadial();
            break;
        case 'cwccw':
            this.drawPolar();
            break;
        }
    }

    drawLinear()
    {
        let ctx = this.canvas.getContext("2d");
        ctx.beginPath();
        ctx.strokeStyle = "#048";
        ctx.lineWidth = 2;
        if(this.playhead_type == "leftright") 
        {
            let x = this.n_position * this.himage.width;
            if(x <= this.himage.width)
            {
                // console.log(`x: ${x}/${this.himage.width}`);
                ctx.moveTo(x, 0);
                ctx.lineTo(x, this.himage.height);
            }
            else
            {
                console.log(`huh? ${this.n_position}, ${this.himage.width}`);
            }
        } 
        else 
        if (this.playhead_type == "updown") 
        {
            let y = this.n_position * this.himage.height + this.himage.heightShift;
            line(this.himage.widthShift, y, this.himage.width + this.himage.widthShift, y);
        }
        ctx.stroke();
    }

    drawRadial() 
    {
        let x = this.himage.widthShift + this.himage.width/2;
        let y = this.himage.heightShift + this.himage.height/2;
        let radius = this.n_position * sqrt(this.himage.width**2 + this.himage.height**2) / 2;

        noFill(); // No fill for the circle, just the outline
        stroke(255, 255, 255, line_alpha); // Red color for the circle outline
        strokeWeight(3); // Set the stroke width 

        ellipse(x, y, radius * 2, radius * 2);
    }

    drawPolar() 
    {
        let centerX = this.himage.widthShift + this.himage.width / 2;
        let centerY = this.himage.heightShift + this.himage.height / 2;
        let angle = this.n_position * TWO_PI - HALF_PI;

        let halfWidth = this.himage.width / 2;
        let halfHeight = this.himage.height / 2;

        let radius = sqrt(halfWidth**2 + halfHeight**2);

        let endX = centerX + radius * Math.cos(angle);
        let endY = centerY + radius * Math.sin(angle);
        stroke(255, 255, 255, line_alpha); // Red color for the line
        strokeWeight(3); // Set the stroke width 

        line(centerX, centerY, endX, endY);
    }
}

exports.Playhead = Playhead;
