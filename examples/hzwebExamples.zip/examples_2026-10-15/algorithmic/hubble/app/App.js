const {Himage} = await Require("./Himage.js");
const {StarSynth} = await Require("./StarSynth.js");
const {ImageSynth} = await Require("./ImageSynth.js");
const {Playhead} = await Require("./Playhead.js");

const canvasTemplate = `
<img style="width:100%;max-width:650px;">
<canvas style="position:absolute;top:0px;left:0px;border-style:solid;border-color:#112;box-sizing:border-box"></canvas>
`;

class App
{
  constructor()
  {
    this.appDir = null;
    this.contentDiv = null;
    this.imageDB = {};
    this.hImage = null;
    this.scale = "whole_tone";
    this.time = 0; // in seconds
    this.isDone = false;
    this.harmonies = 
    {
      major: [0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17, 19, 21, 23],
      minor: [0, 2, 3, 5, 7, 8, 10, 12, 14, 15, 17, 19, 20, 22],
      major_pentatonic: [0, 2, 4, 7, 9, 12, 14, 16, 19, 21],
      minor_pentatonic: [0, 3, 5, 7, 0, 12, 15, 17, 19, 22],
      whole_tone: [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20],
      diminished: [0, 2, 3, 5, 6, 8, 9, 11, 12, 14, 15, 17, 18, 20, 21, 23],
      chromatic: Array.from({length: 24}, (_, i) => i),
      lydian: [0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23],
      mixolydian: [0, 2, 4, 5, 7, 9, 10, 12, 14, 16, 17, 19, 21, 22],
      byzantine: [0, 1, 4, 5, 7, 8, 11, 12, 13, 16, 17, 19, 20, 23],
      asavari:  [0, 1, 5, 7, 8, 12, 13, 17, 19, 20, 24],
      hijaz: [0, 1, 4, 5, 7, 8, 10, 12, 13, 16, 17, 19, 20, 22],
      egyptian:  [0, 2, 5, 7, 10, 12, 14, 17, 19, 22, 24],
    };
    this.start_note = 20;
    this.pitch_mapping = "brightness"; // vs "color"
    this.framerate = 0;
    this.canvas = null;
  }
    
  CurrentTime() 
  {
    return this.time; 
  }

  GetHarmonies() 
  {
    return Object.keys(this.harmonies); 
  }
    
  async Init(appdir, div, fiberCtx, cfg = {})
  {
    this.appDir = appdir;
    this.contentDiv = div;
    this.scale = cfg.harmony || "whole_tone";
    this.hImage = new Himage(this);
    this.cfg = cfg;
    this.imageDB = await this.loadJSON("imageDB.json");
    console.debug("App has imageDB comprising " + this.GetDatasets());
    this.ascene = await Ascene.BeginFiber(fiberCtx);
    let id = `f${fiberCtx.GetId()}:`;
    const dac = this.ascene.GetDAC();
    dac.Show();
    this.reverbNode = await this.ascene.NewAnode("Hz.Freeverb");
    await this.reverbNode.LoadPreset({
      Dry: .6, 
      Wet: .9,
      RoomSize: .8,
    });
    this.reverbNode.Show();
    this.ascene.Chain(this.reverbNode, dac);
    console.debug(`${id} Audio scene is ready to go.`);
  }
    
  GetDatasets()
  {
    return Object.keys(this.imageDB);
  }
    
  async LoadDataset(name)
  {
    console.assert(this.imageDB[name]);
    return this.hImage.LoadDataset(name, this.imageDB[name])
      .then(async(h) =>
      {
        await this.setImage(h);
        if (!this.canvas)
        {
          window.onresize = () =>
          {
            this.updateCanvasSize();
          };
          this.contentDiv.style.overflow = "hidden";
          this.contentDiv.style.position = "relative";
          this.contentDiv.innerHTML = canvasTemplate;
          this.canvas = this.contentDiv.querySelector("canvas");
          this.img = this.contentDiv.querySelector("img");
          this.img.onload = () =>
          {
            this.updateCanvasSize();
          };
          this.img.onerror = () =>
          {
            console.log("couldn't load " + this.hImage.image);
          };
        }
        if (typeof(this.hImage.image) == "string")
        {
          this.img.src = this.hImage.image;
        }
      });
  }
    
  updateCanvasSize()
  {
    // image is sized to fill parent according to width
    // our job is to size the canvas appropriately
    let w = this.img.width;   
    let h = this.img.height;
    this.hImage.width = w;
    this.hImage.height = h;
    // console.log(`canvas resized: ${w} ${h}`);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.canvas.width = w; // critical for coordsys
    this.canvas.height = h;
  }
    
  GetHarmony(offset = 0)
  {
    return this.harmonies[this.scale].map(number => number + this.start_note + offset);
  }
    
  Perform()
  {
    this.animID = 0;
    this.onAnimCallback();
  }
    
  Remap(v, fromMin, fromMax, toMin, toMax)
  {
    let pct = (v - fromMin) / (fromMax - fromMin);
    return toMin + pct * (toMax - toMin);
  }
    
  Constrain(v, min, max)
  {
    if (v < min)return min;
    if (v > max)return max;
    return v;
  }
    
  /* callbacks ---------------------------------------- */
  onAnimCallback(timestamp)
  {
    if (this.lastTime != null)
    {
      let delta = timestamp - this.lastTime;
      this.time += delta / 1000;
      this.framerate = 1000 / delta; // ms
    }
    if (this.framerate != 0)
      this.draw();
            
    this.lastTime = timestamp;
    if (!this.isDone)
      this.animID = requestAnimationFrame(this.onAnimCallback.bind(this));
    else
    {
      this.imageSynth.Stop(); 
      this.starSynth.Stop(); 
    }
  }
    
  async loadImage(name) // return a blob-url (should be revoked onload)
  {
    let ifile = `${this.appDir}/data/${name}.jpg`;
    let data = await globalThis.FetchWSFile(ifile, "arraybuffer");
    const blob = new Blob([data], {type: "image/jpg"});
    const url = URL.createObjectURL(blob);
    return url;
  }
    
  async loadJSON(name)
  {
    let jfile = `${this.appDir}/data/${name}`;
    let str = await globalThis.FetchWSFile(jfile, "text");
    try
    {
      return JSON.parse(str);
    }
    catch (err)
    {
      console.warn(err);
      return null;
    }
  }
    
  /* ---------------------------------------------------------------- */
  async setImage(himage)  // invoked by LoadDataset
  {
    console.assert(himage == this.hImage);
    this.playhead = new Playhead(this, this.hImage);
    if (this.cfg.speed != null)
      this.playhead.SetSpeed(this.cfg.speed);
    this.imageSynth = new ImageSynth(this, this.hImage, this.playhead);
    this.starSynth = new StarSynth(this, this.hImage, this.playhead);
    return this.starSynth.Init(this.cfg.starsynth)
      .then(() =>
      {
        return this.imageSynth.Init(this.cfg.imagesynth);  
      })
      .then(() =>
      {
        this.isPlaying = true;
        this.isDone = false;
      });
  }

  draw(timestamp)  // invoked by onAnimation
  {
    if (this.isDone)return;
    try
    {
      const ctx = this.canvas.getContext("2d");
      ctx.clearRect(0, 0, this.hImage.width, this.hImage.height);

      if (this.isPlaying) 
      {
        this.playhead.incrementPosition();
        this.imageSynth.UpdateOscillators();

        if (this.cfg.starsynth._active) 
        {
          this.starSynth.findStarsToTrigger();
          this.starSynth.playStars();
        }
      }
      this.playhead.draw();
      if (this.cfg.starsynth._active) 
        this.starSynth.animateStars();
    }
    catch (err)
    {
      console.warn(err);
    }
  }
}

exports.App = App;
