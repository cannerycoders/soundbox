
class Himage 
{
  // Constructor method
  constructor(app) 
  {
    this.app = app;
    this.name = null;
    this.info = null;
    this.image = null; // a URL or Image()
    this.LR_grey_data = null;
    this.LR_color_data = null;
    // this.UD_grey_data = null;
    // this.UD_color_data = null;
    // this.polar_grey_data = null;
    // this.polar_color_data = null;
    // this.radial_grey_data = null;
    // this.radial_color_data = null;
        
    this.star_data = null;
    this.canvasWidth = null;
    this.canvasHeight = null;
    this.widthShift = null; // centering only when Image()
    this.heightShift = null;
  }
    
  async LoadDataset(dataset, info)
  {
    let p = [];
    return this.app.loadImage(dataset)
      .then((image) =>
      {
        this.name = dataset;
        this.image = image; // is a url
        return this.app.loadJSON(dataset + "_LR_grey.json");
      })
      .then((data) =>
      {
        this.LR_grey_data = data;
        return this.app.loadJSON(dataset + '_LR_color.json'); //JSON data of star positions and sizes 
      })
      .then((data) =>
      {
        this.LR_color_data = data;
        return this.app.loadJSON(dataset + '_peaks.json'); //JSON data of star positions and sizes 
      })
      .then((data) =>
      {
        this.star_data = data;
        this.info = info;
        console.debug(`${dataset} data received: ${Object.keys(data)}`);
        return this;
      });
  }

  GetImageInfo() 
  {
    return this.info;
  }

}

exports.Himage = Himage;
