const sort_dict =  
{
  leftright: "x_norm",
  updown: "y_norm",
  outin: "r_norm",
  cwccw: "theta_norm",
};
let sort_param = "x_norm"; // Default sort parameter

class StarSynth 
{
  constructor(app, himage, playhead) 
  {
    this.app = app;
    this.ascene = app.ascene;
    this.himage = himage;
    this.playhead = playhead;
    this.star_data = himage.star_data;
    this.star_indexes_to_trigger = [];
    this.stars_to_animate = [];
    this.t_fade = 0.5; //time to fade in and out in seconds, units of seconds
    this.max_star_volume = .8;
    this.sortStars();
  }
    
  async Init(cfg = {_active:true, _prog: 103, Gain: 2})
  {
    this.cfg = cfg;
    if (!cfg._active) 
    {
      console.debug("StarSynth is inactive");
      return;
    }
    this.midiNumbers = this.app.GetHarmony(this.cfg._note_offset);
    this.samplo = await this.ascene.NewAnode("Hz.Samplo");
    if (cfg._prog)
    {
      let kit = "FatBoy"; // vs FluidR3_GM
      let inst = globalThis.MidiGM.NameForProgram(cfg._prog);
      await this.samplo.LoadPreset({instrument: {kit, inst}});
    }
    this.ascene.Connect(this.samplo, this.app.reverbNode);
    return this.ascene.Sync()
        .then(()=>
        {
          for (let k of Object.keys(cfg))
          {
            if (!k.startsWith("_"))
              this.samplo.SetParam(k, cfg[k]); // piano
          }
          this.ascene.Sync();
        })
        .then(() =>
        {
          this.samplo.Show();
        });
  }
    
  Stop()
  {
  }

  sortStars() 
  {
    sort_param = sort_dict[this.playhead.playhead_type];

    const combined = this.star_data.x_norm.map((value, index) => ({
      x_norm: this.star_data.x_norm[index],
      y_norm: this.star_data.y_norm[index],
      size_norm: this.star_data.size_norm[index],
      r_norm: this.star_data.r_norm[index],
      theta_norm: this.star_data.theta_norm[index],
      id: this.star_data.id[index],
      color: this.star_data.color[index]
    }));

    combined.sort((a, b) => a[sort_param] - b[sort_param]);

    const sortedData = 
    {
      x_norm: combined.map(item => item.x_norm),
      y_norm: combined.map(item => item.y_norm),
      size_norm: combined.map(item => item.size_norm),
      r_norm: combined.map(item => item.r_norm),
      theta_norm: combined.map(item => item.theta_norm),
      id: combined.map(item => item.id),
      color: combined.map(item => item.color)
    };

    this.star_data = sortedData;
  }

  sortStarsMatrix() 
  {
    sort_param = sort_dict[this.playhead.playhead_type];
    // Step 1: Get the index of the row to sort by using the key
    const keys = Object.keys(this.star_data);
    const sortIndex = keys.indexOf(sort_param);
    
    if (sortIndex === -1) 
    {
      console.error(`Invalid sort key: ${sort_param}`);
      return;
    }
    
    // Step 2: Convert the dictionary values to a matrix
    const matrix = Object.values(this.star_data);
    
    // Step 3: Transpose the matrix
    const transpose = (matrix) => matrix[0].map((_, colIndex) => matrix.map(row => row[colIndex]));
    const transposedMatrix = transpose(matrix);
    
    // Step 4: Sort the transposed matrix by the specified row
    transposedMatrix.sort((a, b) => a[sortIndex] - b[sortIndex]);
    
    // Step 5: Transpose the matrix back to its original form
    const sortedMatrix = transpose(transposedMatrix);
    
    // Step 6: Convert the sorted matrix back to the original dictionary format
    const sortedData = {};
    keys.forEach((key, index) => 
    {
      sortedData[key] = sortedMatrix[index];
    });
    
    this.star_data = sortedData;
  }

  filterLargestStars(starIndexes, n)
  {
    let threshold = 0.0;
    const filteredIndexes = starIndexes.filter(index => 
    {
      const size = this.star_data.size_norm[index];
      return size > threshold;
    });

    const sortedIndexes = filteredIndexes.sort((a, b) => 
    {
      const sizeA = this.star_data.size_norm[a];
      const sizeB = this.star_data.size_norm[b];
      return sizeB - sizeA;
    });
        
    return sortedIndexes.slice(0, n);
  }
    
  removeOldStars() 
  {
    let t = this.app.CurrentTime();
    this.stars_to_animate = this.stars_to_animate.filter(star => 
        this.playhead.direction_sign * (t - star.t) <= 2 * this.t_fade);
  }

  addStarIndex(i) 
  {
    this.star_indexes_to_trigger.push(i);
    this.stars_to_animate.push({
      't': this.app.CurrentTime(), 
      'n_position':this.playhead.n_position,
      'x_norm':this.star_data.x_norm[i],
      'y_norm':this.star_data.y_norm[i],
      'size_norm':this.star_data.size_norm[i],
      'id':this.star_data.id[i]
    });
  }
    
  findStarsToTrigger() 
  {
    let npos = this.playhead.n_position;
    let dpos = this.playhead.delta_n_position;
    this.star_indexes_to_trigger = [];
    if (npos <= dpos)
      return;
    else if (npos >= 1 - dpos) 
      return;
    else 
    {
      if (this.playhead.direction_sign == 1) 
      {
        let closestLesserIndex = this.findClosestLesserIndex(npos);
        let prevClosestLesserIndex = this.findClosestLesserIndex(npos - dpos);
                
        if (closestLesserIndex == prevClosestLesserIndex) 
        {
          if (this.star_data[sort_param][closestLesserIndex] >= npos - dpos 
              && this.star_data[sort_param][closestLesserIndex] < npos) 
          {
            this.addStarIndex(closestLesserIndex);
          } 
          else
            return;
        } 
        else 
        {
          for (let i = prevClosestLesserIndex + 1; i <= closestLesserIndex; i++) 
          {
            this.addStarIndex(i);
          }
        }
      }
      else 
        if (this.playhead.direction_sign == -1) 
        {
          let closestGreaterIndex = this.findClosestGreaterIndex(npos);
          let prevClosestGreaterIndex = this.findClosestLesserIndex(npos + dpos);
          if (closestGreaterIndex == prevClosestGreaterIndex) 
          {
            if (this.star_data[sort_param][closestGreaterIndex] > npos 
              && this.star_data[sort_param][closestGreaterIndex] <= npos + dpos) 
            {
              this.addStarIndex(closestGreaterIndex);
            } 
            else 
              return;
          } 
          else 
          {
            for (let i = closestGreaterIndex; i <= prevClosestGreaterIndex; i++)
              this.addStarIndex(i);
          }
        }
        this.removeOldStars();
        return;
    }
  }

  animateStars() 
  {
    let t = this.app.CurrentTime();
    let ctx = this.app.canvas.getContext("2d");
    for (let star of this.stars_to_animate)
    {
      let dt = t - star.t;
      const size = 50 * star.size_norm * dt / this.t_fade;
      if (size > 0)
      {
        const x = this.app.Remap(star.x_norm, 0, 1, 0, this.himage.width);
        const y = this.app.Remap(star.y_norm, 0, 1, 0, this.himage.height);
        const alpha = Math.exp(-Math.pow(dt, 2) / (2 * Math.pow(this.t_fade, 2)));
        ctx.beginPath(); // Start a new drawing path
        ctx.arc(x, y, size, 0, 2 * Math.PI); // Define the circle
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }
  }

  playStars() 
  {
    // Play the stars that are in the `star_indexes_to_trigger` array

    this.star_indexes_to_trigger.forEach(index => 
    {
      const size = this.star_data.size_norm[index];
      let pitch_value = size;
      if (this.app.pitch_mapping == 'brightness') 
        pitch_value = size ** 0.5;
      else 
        if (this.app.pitch_mapping == 'color')
          pitch_value = this.star_data.color[index];
      const midiNoteIndex = Math.floor(this.app.Remap(pitch_value, 0,  1, 0, this.midiNumbers.length - 1));
      const midiNote = this.midiNumbers[midiNoteIndex];
      const volume = this.app.Remap(size ** 1, 0, 1, 0, this.max_star_volume);
        this.playSound(midiNote, volume); 
    });
  }

  findClosestLesserIndex(target) 
  {
    let arr = this.star_data[sort_param];
    let start = 0;
    let end = arr.length - 1;
    let mid;

    while (start <= end) 
    {
      mid = Math.floor((start + end) / 2);
    
      if (arr[mid] === target) 
      {
        return mid;
      }
      else if (arr[mid] < target) 
      {
        start = mid + 1;
      }
      else 
      {
        end = mid - 1;
      }
    }
    
    // If no exact match is found, end will be pointing to the closest lesser value
    if (this.playhead.direction_sign == 1)
      return end >= 0 ? end : this.star_data[sort_param].length - 1;
    else if (this.playhead.direction_sign == -1)
      return end >= 0 ? end : 0;
  }

  findClosestGreaterIndex(target) 
  {
    let arr = this.star_data[sort_param];
    let start = 0;
    let end = arr.length - 1;
    while (start <= end) 
    {
      let mid = Math.floor((start + end) / 2);
    
      if (arr[mid] === target)
        return mid;
      else if (arr[mid] < target) 
        start = mid + 1;
      else
        end = mid - 1;
    }
    
    // If no exact match is found, start will be pointing to the closest greater value
    return start < arr.length ? start : this.star_data[sort_param].length - 1;
  }
    
  // Function to play a sound buffer with a specified volume
  playSound(note, volume) 
  {
    // console.log(`star: ${note} ${volume}`);
    this.samplo.Note(note, volume, this.ascene.Seconds(.5), 0);
  }

}

exports.StarSynth = StarSynth;
