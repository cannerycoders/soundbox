NB: this code is a port of "Hearing Hubble" found here:

https://science.nasa.gov/specials/apps/hearing-hubble/

Copyright status: Because it's produced by NASA (a U.S. federal agency), 
the "Hearing Hubble" web app and its underlying code are, as with most 
NASA-produced content, generally not subject to copyright in the United 
States — this covers images, audio, video, related media and files that 
make up the app. So there isn't a formal software license 
(like MIT or GPL) attached — it's a work of the U.S. government, 
which under 17 U.S.C. §105 falls outside copyright protection 
domestically. 

Data for `ngc1850-blue` can be found here:

https://www3.nasa.gov/specials/hubble-hearing-app/data/ngc1850-blue/ngc1850-blue_peaks.json

https://www3.nasa.gov/specials/hubble-hearing-app/data/ngc1850-blue/ngc1850-blue_LR_grey.json

https://www3.nasa.gov/specials/hubble-hearing-app/data/ngc1850-blue/ngc1850-blue_LR_color.json

Additional playhead data for `_UD_`, `_polar_`, `_radial_` follows the pattern
of `_LR_` above.

