const {App} = await this.Require("./app/App.js"); // load our Hubble app
const Hubble = new App();
const thisDir = path.dirname(this.GetFilePath());
const content = document.querySelector(".Content");
content.insertAdjacentHTML("beforeend", 
      "<div style='padding:5px' id='HubbleApp'></div>");
const div = content.querySelector("#HubbleApp");// select a random harmony (scale).
const harmonies = Hubble.GetHarmonies();
const doShutdown = false;
const harmony = harmonies[Math.floor(Math.random()*harmonies.length)];
console.log("Using scale: " + harmony);
const appConfig = {
    harmony: harmony,
    speed: .33,
    starsynth: {_active: true, _note_offset: 3, _prog: 103, Gain: 2},
    imagesynth: {_active: true, _note_offset: -10, Gain: 1.2, Waveform: 1},
};
const dataset = "ngc1850-blue"; // this is the only dataset we include
div.innerHTML = `<h3>Loading ${dataset}</h3>`;
await Hubble.Init(thisDir, div, this/*fiberCtx*/, appConfig);
await Hubble.LoadDataset(dataset);
Hubble.ascene.VisualizeGraph();
console.log(`Performing ${dataset}`);
Hubble.Perform(); // happens via callbacks, ie: in the bgd.
let interval = Hubble.ascene.Seconds(.5);
while(!Hubble.isDone)
{
  await Hubble.ascene.Wait(interval);
  let msg = yield;
  if(msg == "_cancel_") // supports cancellation from AudioMonitor
  {
    console.log("Hubble cancelled.");
    Hubble.isDone = true;
  }
}
if(doShutdown)
  Aengine.Close(); // kills all running audio