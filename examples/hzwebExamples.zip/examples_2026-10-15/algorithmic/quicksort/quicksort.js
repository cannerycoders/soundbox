// Use JS sort with callbacks to generate notes. Performance starts
// with random notes and "evolves" toward a scale.

let scene = await Ascene.BeginFiber(this); 
let dac = scene.GetDAC();
dac.Show();

let inst = await scene.NewAnode("Hz.FM7", {preset: {Bank:1, Patch:5}});
inst.Show();

let drum = await scene.NewAnode("GeneralMIDI", {preset: {presetName: "percussion"}});
drum.Show();

let drumNotes = ["lt", "bd", "sd1"].map((nm) => 
{
  return MidiGM.NoteForName(nm);
});

scene.Chain(inst, dac);
scene.Chain(drum, dac);

scene.VisualizeGraph();

// Create a range of notes from a scale. Repeat them, then shuffle.
let notes = Tonal.Scale.rangeOf("C Minor")("C2", "C6").map((nm) => Tonal.Note.midi(nm));
let manyNotes = repeat(notes, 5);
shuffle(manyNotes);

// Now we have a random collection of notes from our scale. 
// Let's sort them, recording each sorting comparison action.
let dur = scene.Seconds(.05);
let intervalDur = scene.Seconds(.12);
let nextTime = scene.Seconds(.18);
let noteList = [];
manyNotes.sort((a, b) =>
{
  if(a < b)
    ret = -1;
  else
  if(b > a)
    ret = 1;
  else
    ret = 0;
  noteList.push([a, .9, dur+Math.random(dur), nextTime]);
  nextTime += intervalDur;
  return ret;
});

console.log(`Sorting ${manyNotes.length} notes produced ${noteList.length} events.`);
for(let i=0;i<noteList.length;i++)
{
  let [key, vel, dur, when] = noteList[i];
  inst.Note(key, vel, dur, when);
  if(i%4 == 0)
    drum.Note(drumNotes[1], .6, dur, when);
  else
    drum.Note(drumNotes[Random.Choose([0,2])], .5, dur, when);
  await scene.Wait(.9*intervalDur);
  yield;
}

function shuffle(array) 
{
  let currentIndex = array.length;
  while(currentIndex != 0)
  {
    let randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;

    [array[currentIndex], array[randomIndex]] = [
              array[randomIndex], array[currentIndex]];
  }
}

function repeat(arr, n) 
{
  return Array(n).fill(arr).flat();
}
