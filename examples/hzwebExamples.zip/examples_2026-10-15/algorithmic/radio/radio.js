//
// This example combines internet-based radio stations with
// aother internet resources, zenquotes and bbbc headlines,
// to produce a soundscape that changes each time you run it.
//
// By default, recording is active so when the performance
// is complete, a new .wav file will appear in your workspace.
// The duration of the performance is determined by the headlines;
// their number and length.  Modify maxHeadlines to shorten or 
// lengthen the performance.
// 
// https://en.wikipedia.org/wiki/List_of_Internet_radio_stations
// Icecast directory: https://dir.xiph.org/
// There are q few types of internet radio streams ()
//  1. a url suffices to connect to html5 stream (.mp3, .aac)
//  2. a url may be redirected and utilize context to
//   validate/track the stream.  
//  3. a uri which produces a playlist
// Currently we support #1.

let now = new Date();
let ascene = await Ascene.BeginFiber(this);
let id = `t${this.GetId()}:`;

console.log(`${id}: Warming up the radio tubes....`);

// debugger;
let state = {
  maxHeadlines: 5, // number determines duration
  maxStations: 10,
  doRecord: true,
  done: false,
  ascene,
  streamStates: [], // sparse array
  repeatRangeMS: [7000, 12000],
};

const {BuildRadioButtons, ToggleStation} = await this.Require("./app/gui.js");
const {Stations, ActivateStation} = await this.Require("./app/stations.js");
state.substations = Random.Shuffle(Stations).slice(0, state.maxStations);

BuildRadioButtons(state.substations, ActivateStation, state);

const {Morse, Feeds} = await this.Require("./app/morse.js");
const {Headlines} = await this.Require("./app/headlines.js");
const {Modulator} = await this.Require("./app/modulator.js");
const {Sweeper} = await this.Require("./app/sweeper.js");
const {CreateInstruments} = await this.Require("./app/instruments.js");

state.headlines =await Headlines(state.maxHeadlines); // <--- takes a few seconds

await CreateInstruments(state); // <-- takes a few seconds..

Modulator(state); // runs asynchronously, modulates parameters

if(state.recordNode)
{
  let ts = Util.GetFileTimestamp();
  await state.recordNode.LoadPreset({
      ctrlMode: "Preset",
      prefix: "radio_" + ts,
      recordStart: 0,
      recordEnd: 1e10, // need to trigger end
  });
}

// trigger (ON) GUI checkboxes for 4 favorite stations
ToggleStation(0);
ToggleStation(1);
ToggleStation(2);
ToggleStation(3);

let toMorse = new Morse(70, .1); // note, rate
for(let txt of state.headlines)
{
  for await (const value of Sweeper(state))
    yield;
    
  for await (const value of toMorse.PerformText(ascene, state.morseInst, txt))
    yield;
}
console.log("Enough with the noise, fade to darkness.");

state.done = true; // signal Modulator to stop modulating.

// trigger (OFF) GUI checkboxes for 4 favorite stations
let w = ascene.Seconds(.1);
for(let i=0;i<100;i++)
{
  state.dac.SetParam("Gain", state.dacGain * (1 - i/99));
  await ascene.Wait(w);
}

if(state.recordNode)
{
  await state.recordNode.LoadPreset(
    {
      ctrlMode: "Preset",
      disarm: true, // <---- stop recording
      recordEnd: ascene.Now(),
    });
}

await ascene.Wait(ascene.Seconds(2));
await Aengine.Close();
console.log("radio: dark.")
