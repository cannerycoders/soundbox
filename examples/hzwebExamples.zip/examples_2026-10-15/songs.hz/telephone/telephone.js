//
// NB: this is the driver for telephone.hz.
// Launch via "Run in sandbox...".
// 
const thisDir = path.dirname(this.GetFilePath());
const songFile = "telephone.hz";
const songPath = path.join(thisDir, songFile);
const telephoneInstPath = path.join(thisDir, "telephoneInst.json");
let str = await FetchWSFile(songPath, "text");
let songbook = new Songbook(str, songFile); 

const InitVoice = async function(scene, cwd, options)
{
  let dac = scene.GetDAC();
  if(!dac._rev)
  {
    await dac.LoadPreset({Gain: 1.1});
      
    dac._rev = await scene.NewAnode("Hz.ConvVerb", {
      Wet: .4, Dry: .6
    });
    scene.Chain(dac._rev, dac);
    dac.Show();
    dac._rev.Show();
  }
    
  let inst = await scene.NewAnode("Hz.Samplo",{name:options.name});;
  switch(options.name)
  {
  case "telephone":
    await inst.LoadPreset({
      instrument: {
        kit: "Workspace", 
        inst: telephoneInstPath,
      }
    });
    break;
  default:
    await inst.LoadPreset({
      instrument: {
        kit: "GeneralMIDI",
        inst: options.name
      }
    });
    break;
  }
  inst.Show();
  scene.Chain(inst, dac._rev);
  await scene.Sync();
  return [inst];
};

for await (const val of songbook.PerformSong(this, {InitVoice}))
  yield;