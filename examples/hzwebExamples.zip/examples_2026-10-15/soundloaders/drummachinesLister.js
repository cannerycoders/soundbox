//
// This example list all sound buffers for all
// instruments of drum-machines samples found here:
//   https://smpldsnds.github.io/drum-machines
//
const instlist = await DrumMachinesLoader.GetInstruments();
for (let inm of instlist)
{
  let itoc = await DrumMachinesLoader.GetInstTOC(inm);
  let soundnames = itoc.soundnames;
  let table = [`|${inm}| ${soundnames.length} voices|`,
    "|:--|:--|"
  ];
  for (let i = 0;i < soundnames.length;i++)
  {
    table.push(`|${i}|${soundnames[i]}|`);
  }
  console.log(`\nDrumMachines/${inm} ===========\n${table.join("\n")}`);
}


/* produces this output

15:46 note sb0: DrumMachines/Yamaha-MR10 ===========
|Yamaha-MR10| 14 voices|
|:--|:--|
|0|brush|
|1|chihat|
|2|crash|
|3|cymbal|
|4|hitom|
|5|kick|
|6|kick1|
|7|lowtom|
|8|midtom|
|9|ohihat|
|10|shaker|
|11|shorthi|
|12|shortsn|
|13|snare|

15:46 note sb0: DrumMachines/Roland-CR-8000 ===========
|Roland-CR-8000| 13 voices|
|:--|:--|
|0|clap|
|1|clave|
|2|conga-high|
|3|conga-low|
|4|cowbell|
|5|cymball|
|6|hihat-closed|
|7|hihat-open|
|8|kick|
|9|rimshot|
|10|snare|
|11|tom-high|
|12|tom-low|

15:46 note sb0: DrumMachines/Casio-SK1 ===========
|Casio-SK1| 6 voices|
|:--|:--|
|0|hihat-open|
|1|hithat|
|2|kick|
|3|snare|
|4|tom-hi|
|5|tom-low|

15:46 note sb0: DrumMachines/808-mini ===========
|808-mini| 13 voices|
|:--|:--|
|0|crash|
|1|hhclosed-1|
|2|hhclosed-2|
|3|hhopen-1|
|4|hhopen-2|
|5|kick|
|6|ride|
|7|snare-1|
|8|snare-2|
|9|snare-3|
|10|tom-high|
|11|tom-low|
|12|tom-mid|

15:46 note sb0: DrumMachines/TR-808 ===========
|TR-808| 116 voices|
|:--|:--|
|0|clap/cp|
|1|clave/cl|
|2|conga-hi/hc00|
|3|conga-hi/hc10|
|4|conga-hi/hc25|
|5|conga-hi/hc50|
|6|conga-hi/hc75|
|7|conga-low/lc00|
|8|conga-low/lc10|
|9|conga-low/lc25|
|10|conga-low/lc50|
|11|conga-low/lc75|
|12|conga-mid/mc00|
|13|conga-mid/mc10|
|14|conga-mid/mc25|
|15|conga-mid/mc50|
|16|conga-mid/mc75|
|17|cowbell/cb|
|18|cymbal/cy0000|
|19|cymbal/cy0010|
|20|cymbal/cy0025|
|21|cymbal/cy0050|
|22|cymbal/cy0075|
|23|cymbal/cy1000|
|24|cymbal/cy1010|
|25|cymbal/cy1025|
|26|cymbal/cy1050|
|27|cymbal/cy1075|
|28|cymbal/cy2500|
|29|cymbal/cy2510|
|30|cymbal/cy2525|
|31|cymbal/cy2550|
|32|cymbal/cy2575|
|33|cymbal/cy5000|
|34|cymbal/cy5010|
|35|cymbal/cy5025|
|36|cymbal/cy5050|
|37|cymbal/cy5075|
|38|cymbal/cy7500|
|39|cymbal/cy7510|
|40|cymbal/cy7525|
|41|cymbal/cy7550|
|42|cymbal/cy7575|
|43|hihat-close/ch|
|44|hihat-open/oh00|
|45|hihat-open/oh10|
|46|hihat-open/oh25|
|47|hihat-open/oh50|
|48|hihat-open/oh75|
|49|kick/bd0000|
|50|kick/bd0010|
|51|kick/bd0025|
|52|kick/bd0050|
|53|kick/bd0075|
|54|kick/bd1000|
|55|kick/bd1010|
|56|kick/bd1025|
|57|kick/bd1050|
|58|kick/bd1075|
|59|kick/bd2500|
|60|kick/bd2510|
|61|kick/bd2525|
|62|kick/bd2550|
|63|kick/bd2575|
|64|kick/bd5000|
|65|kick/bd5010|
|66|kick/bd5025|
|67|kick/bd5050|
|68|kick/bd5075|
|69|kick/bd7500|
|70|kick/bd7510|
|71|kick/bd7525|
|72|kick/bd7550|
|73|kick/bd7575|
|74|maraca/ma|
|75|mid-tom/mt00|
|76|mid-tom/mt10|
|77|mid-tom/mt25|
|78|mid-tom/mt50|
|79|mid-tom/mt75|
|80|rimshot/rs|
|81|snare/sd0000|
|82|snare/sd0010|
|83|snare/sd0025|
|84|snare/sd0050|
|85|snare/sd0075|
|86|snare/sd1000|
|87|snare/sd1010|
|88|snare/sd1025|
|89|snare/sd1050|
|90|snare/sd1075|
|91|snare/sd2500|
|92|snare/sd2510|
|93|snare/sd2525|
|94|snare/sd2550|
|95|snare/sd2575|
|96|snare/sd5000|
|97|snare/sd5010|
|98|snare/sd5025|
|99|snare/sd5050|
|100|snare/sd5075|
|101|snare/sd7500|
|102|snare/sd7510|
|103|snare/sd7525|
|104|snare/sd7550|
|105|snare/sd7575|
|106|tom-hi/ht00|
|107|tom-hi/ht10|
|108|tom-hi/ht25|
|109|tom-hi/ht50|
|110|tom-hi/ht75|
|111|tom-low/lt00|
|112|tom-low/lt10|
|113|tom-low/lt25|
|114|tom-low/lt50|
|115|tom-low/lt75|

15:46 note sb0: DrumMachines/MFB-512 ===========
|MFB-512| 9 voices|
|:--|:--|
|0|clap|
|1|cymbal|
|2|hihat-closed|
|3|hihat-open|
|4|kick|
|5|snare|
|6|tom-hi|
|7|tom-low|
|8|tom-mid|

15:46 note sb0: DrumMachines/LM-2 ===========
|LM-2| 29 voices|
|:--|:--|
|0|cabasa|
|1|clap|
|2|conga-h|
|3|conga-hh|
|4|conga-l|
|5|conga-ll|
|6|conga-lll|
|7|conga-m|
|8|cowbell|
|9|crash|
|10|hhclosed-long|
|11|hhclosed-short|
|12|hhclosed|
|13|hhopen|
|14|kick-alt|
|15|kick|
|16|ride|
|17|snare-h|
|18|snare-l|
|19|snare-m|
|20|stick-h|
|21|stick-l|
|22|stick-m|
|23|tambourine|
|24|tom-h|
|25|tom-hh|
|26|tom-l|
|27|tom-ll|
|28|tom-m|

15:46 note sb0: DrumMachines/Micro-Rhythmer-12 ===========
|Micro-Rhythmer-12| 3 voices|
|:--|:--|
|0|univox-ch|
|1|univox-oh|
|2|univox-sd|

15:46 note sb0: DrumMachines/Casio-RZ1 ===========
|Casio-RZ1| 12 voices|
|:--|:--|
|0|clap|
|1|clave|
|2|cowbell|
|3|crash|
|4|hihat-closed|
|5|hihat-open|
|6|kick|
|7|ride|
|8|snare|
|9|tom-1|
|10|tom-2|
|11|tom-3|

15:46 note sb0: DrumMachines/Sequential-Circuits-Drumtraks ===========
|Sequential-Circuits-Drumtraks| 13 voices|
|:--|:--|
|0|DT_Cabasa|
|1|DT_Clap|
|2|DT_Closedhat|
|3|DT_Cowbell|
|4|DT_Crash|
|5|DT_Kick|
|6|DT_Openhat|
|7|DT_Ride|
|8|DT_Rimshot|
|9|DT_Snare|
|10|DT_Tamborine|
|11|DT_Tom01|
|12|DT_Tom02|

*/