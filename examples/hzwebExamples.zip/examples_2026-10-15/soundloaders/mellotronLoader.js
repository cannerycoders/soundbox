const toc = await MellotronLoader.GetTOC();
console.log("Mellotron instruments\n" + Object.keys(toc));
const inst = await MellotronLoader.GetInst("300 STRINGS");

console.log("inst loaded " + Object.keys(inst));

let actx = new AudioContext();
let notes = Object.keys(inst);

function playNotes()
{
  if (notes.length > 0)
  {
    let key = notes.pop();
    let buf = inst[key];
    let sbuf = actx.createBufferSource();
    sbuf.connect(actx.destination);
    console.log(`${key} t:${actx.currentTime}`);
    sbuf.buffer = buf;
    sbuf.start(actx.currentTime);
    sbuf.onended = () =>
    {
      sbuf.disconnect(actx.destination);
      playNotes();
    };
  }
}

actx.resume();
playNotes();