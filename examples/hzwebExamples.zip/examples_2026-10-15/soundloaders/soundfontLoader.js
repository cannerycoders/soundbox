const inst = await SfLoader.GetInst("FatBoy", "vibraphone");

console.log("inst loaded " + Object.keys(inst));

let actx = new AudioContext();
let notes = Object.keys(inst);

function playNote(key)
{
  return new Promise((resolve, reject) =>
  {
    let buf = inst[key];
    let sbuf = actx.createBufferSource();
    sbuf.connect(actx.destination);
    console.log(key,  actx.currentTime);
    sbuf.buffer = buf;
    sbuf.start(actx.currentTime);
    sbuf.onended = () =>
    {
      sbuf.disconnect(actx.destination);
      resolve(key);
    };
  });
}

for(let n of notes)
{
  console.log("play " + n);
  await playNote(n);
  yield; // to musicAPI scriptrunner/fibermgr.
}