const toc = await VCSLLoader.GetTOC();
console.log("VCSL instruments\n" + Object.keys(toc));
const inst = await VCSLLoader.GetInst("Electrophones/TX81Z/FM Piano");

console.log("inst loaded " + Object.keys(inst));

let actx = new AudioContext();
let notes = Object.keys(inst);

function playNotes()
{
  if (notes.length > 0)
  {
    let key = notes.pop();
    let buf = inst[key];
    let sbuf = actx.createBufferSource();
    sbuf.connect(actx.destination);
    console.log(key,  actx.currentTime);
    sbuf.buffer = buf;
    sbuf.start(actx.currentTime);
    sbuf.onended = () =>
    {
        sbuf.disconnect(actx.destination);
        playNotes();
    };
  }
}

actx.resume();
playNotes();