//
// This example plays all sound buffers for all
// instruments of soundbox samples found here:
//   https://cannerycoders.github.io/soundbox
// and here:
//   https://cannerycoders.github.io/soundbox/toc.json
//
const {SoundboxLoader} = globalThis;
const instlist = await SoundboxLoader.GetInstruments();
console.log("All Soundbox:\n" + instlist);

let actx = new AudioContext();
for (let inm of instlist)
{
  await playSounds(inm);
}
console.log("done");

async function playSounds(inm)
{
  return new Promise((resolve) =>
  {
    console.log(`${inm} --------------------`);
    SoundboxLoader.GetInst(inm, {audioContext: actx})
    .then((inst) =>
    {
      let sounds = inst.sounds();
      let index = 0;
      let tot = sounds.length;
      
      let playNotes = function()
      {
        if (sounds.length > 0)
        {
          let key = sounds.shift();
          let buf = inst[key];
          let sbuf = actx.createBufferSource();
          sbuf.connect(actx.destination);
          console.log(`${index++}/${tot}: ${key}`, actx.currentTime.toFixed(2));
          sbuf.buffer = buf;
          sbuf.start(actx.currentTime);
          sbuf.onended = () =>
          {
              sbuf.disconnect(actx.destination);
              playNotes();
          };
        }
        else
          resolve(0);
      };
      actx.resume();
      playNotes();
    });
  });
}