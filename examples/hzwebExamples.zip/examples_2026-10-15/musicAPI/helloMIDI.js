//
// This example follows helloAnode.js is shows how to
// perform live MIDI events. Of course that means you'll
// need an input device like a MIDI keyboard.
// 
const scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();
let inst = await scene.NewAnode("Hz.Samplo");
inst.Show();
 
// load samples from the internet
await inst.LoadPreset(
{
  instrument: {kit: "FatBoy", inst: "vibraphone"},
  adsr: {
      attack: 0, // soundfonts have a natural attack env.
      decay: 0,
      sustain: 1,
      release: 1.5, // user releases prior to end of sbuf.
    },
    Gain: 5,
});
inst.Show();

let scope = await scene.NewAnode("Hz.Scope");
scope.Show();

scene.Chain(inst, scope, dac);
scene.VisualizeGraph();

// Open the default MIDI input device.
let port = 0;
let midiInput = new MidiIn(port);
let ok = await midiInput.Open();
console.log("midiInput.open returned " + ok);

// wait forever for MIDI input.  When one is received
// use deliver it to our instrument for performance.
// Note that both midiInput.Recv and yield participate
// in the asynchronous operation of the script.

let i = 0;
let debugMIDI = false;
while(true)
{
  let data = await midiInput.Recv(); // "blocks" until activity
  if(debugMIDI) console.log(`${i++}: ${data}`);
  inst.MidiEvent(data);
  let msg = yield; // support for cancelation via fibers panel.
  if(msg == "_cancel_") break;
}
console.log("midiInput.close");
midiInput.Close();

