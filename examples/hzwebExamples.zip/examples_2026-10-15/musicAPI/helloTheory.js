const mt = globalThis.MusicTheory;

console.log("C gypsy midi keys", 
  mt.GetScaleKeys("C gypsy", 3, 4));

console.log("ChordtypeKeys('dim7', 'C2')", 
  mt.GetChordtypeKeys("dim7", "C2"));
  
for (let cnm of ["C7/B", "CMaj7/B", "Cmaj7", "C6add9", "IV"])
{
  console.log(`ChordnameToKeys('${cnm}')`, 
    mt.ChordnameToKeys(cnm));
}

for (let s of ["C major", "C minor", "C gypsy"])
{
  console.log(`GetScaleChordKeys('${s}', 2, 3)`,  
    mt.GetScaleChordKeys(s, 2, 3));
}

for (let c of ["C", "Cmaj7/B", "C6add9", "c6", "IV", "maj7", "Eb maj7"])
{
  console.log(`Chord.get(${c})`, mt.Tonal.Chord.notes(c));
}