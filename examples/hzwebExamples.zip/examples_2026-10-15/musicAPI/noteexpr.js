// This example shows how to deliver note-expression events 
// (like pan, frequency, etc) to *individual* notes while held. 
// 
// Here we play a *single* note, then use NoteExpression to modify 
// its characteristics. 
// 
// Note that this capability has limited in MIDI and therefore 
// some of the capabilities require Hz.Plugins.
//
// Instruments must support a basic set of note expressions: 
//   * "pan"
//   * "volume"
//   * "tuning"
// 
// Instruments may support other standard expressions:
//   * "brightness"
//   * "expression"
//   * "vibrato"
//   * "pressure"
// 
// Some instruments support custom expressions:
//   * "_frequency"  (Hz.Osc)
//
// Note that for a single held note, changing a parameter
// via the GUI has no effect.  This is because Hz.Osc
// currently samples them at note-on.
//
const {Ascene, Anode, Random} = globalThis;
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let inst = await Anode.New("Hz.Osc");
await inst.LoadPreset({
    Waveform: 1,
    Gain: .5,
    A: .1,
    D: .01,
    S: 1,
    R: .04,
  });
inst.Show();

let scope = await scene.NewAnode("Hz.Scope", {acfg: {channelCount:2}});
scope.Show();

scene.Chain(inst, scope, dac);

let [noteid, _] = inst.NoteOn(40, 1);
let interval = scene.Seconds(.1);

// 100 different settings for our single note.
for (let i = 0;i < 100;i++)
{
  await scene.Wait(interval);
  inst.NoteExpression("_frequency", Random.InRange(100, 500), 0, noteid);
  inst.NoteExpression("expression", Random.InRange(.2, 1), 0, noteid);
  inst.NoteExpression("pan", Random.InRange(0, 1), 0, noteid);
}

await scene.Wait(interval);
inst.NoteOff(40, 1, 0/*now*/, noteid);


