// Aengine is the beating heart of the audio subsystem. 
// Usually it is managed by Ascene and therefore less central
// to your scripts.  Here we simply open a connection
// to Aengine.  Next we wait for 5 seconds, then we shut
// it down.  
//
// To run the script right-click -> "Run in Sandbox".
// 
// Note that no sound is produced by this example.
// 
const {Aengine} = globalThis;
await Aengine.Open();
console.log(`hello Aengine ` + Aengine.GetCurrentTimestamp(true));
await Aengine.Wait(Aengine.Seconds(5));
console.log("hello2 " + Aengine.GetCurrentTimestamp(true));

// out-of-band closure.
setTimeout(() =>
{
  console.log("after 15s, closing.");
  console.log("goodbye Aengine " + Aengine.GetCurrentTimestamp(true));
  Aengine.Close();
}, 15000);