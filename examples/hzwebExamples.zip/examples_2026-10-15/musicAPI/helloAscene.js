//
// Ascene is the audio scene context for this script.
// For most uses, this is the primary MusicAPI/audio context and
// you can use it to create Anodes, interop with Aengine, etc.
// 
// Typically an instance is created at the top of your script 
// via BeginFiber.  When you run the same script twice in
// quick sucession, you'll see that two independent *fibers*
// are created.
//
// DAC is a special audio node in the system that represents
// the audio output of your script.  In WebAudio, this is
// referred to as the audio context *destination*.
// 
// To run the script right-click -> "Run in Sandbox".
// 
// Since nothing is connected to the DAC, this example produces
// no sound.
// 
const {Ascene} = globalThis;
const scene = await Ascene.BeginFiber(this);
console.log("hello Ascene");
const dac = scene.GetDAC();
dac.Show();