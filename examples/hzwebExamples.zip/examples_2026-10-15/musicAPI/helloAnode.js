//
// This example builds atop helloAscene.  
// Here we instantiate an Audio Node (anode) and request
// ascene to chain its output to the DAC.
// Next we produce random notes that produce an actual audio signal.
// 
// To run the script right-click -> "Run in Sandbox".
// 
// Note that you can run this script multiple times in 
// quick succession.  If you inspect the Sandbox panel
// you'll see a *single* DAC, but multiple Hz.Osc anodes.
//
// You can cancel individual fibers in the Fibers panel.
// 
const {AScene} = globalThis;
const scene = await Ascene.BeginFiber(this);
console.log("hello ascene");
const dac = scene.GetDAC();
dac.Show();
let osc = await Anode.New("Hz.Osc", {
  preset: {
    Gain: .1,
    Waveform: 1,
    A: .1,
    R: 1,
  }
});
scene.Chain(osc, dac);
osc.Show();

await scene.VisualizeGraph();

let latency = Aengine.Seconds(.5);
let start = Aengine.GetCurrentTime() + latency;
let interval = Aengine.Seconds(.25);
let legato = 2;
let nnotes = 12 * 20;
let kbase = 40 + Math.floor(20 * Math.random());
for(let i=0;i<nnotes;i++)
{
  let key = kbase + 19 * Math.random();
  let vel = .6 + .4 * Math.random();
  osc.Note({key, velocity:vel, dur:legato*interval, when:start});
  await Aengine.Wait(interval);
  start += interval;
  yield;
}