let port = 0;
let midiInput = new MidiIn(port);
let ok = await midiInput.Open();
console.log("midiInput.open returned " + ok);
for (let i = 0;i < 30;i++)
{
  let data = await midiInput.Recv(); // "blocks" until activity
  console.log(`${i}: ${data}`);
}
console.log("midiInput.close");
midiInput.Close();