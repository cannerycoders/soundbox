
let f = "Bach_Cantate_BWV20.mid";
let url = path.join(this.GetCWD(), "midifiles", f);
let midiFile = new MidiFile();
let err = await midiFile.Load(url);
midiFile.Dump({
  dumpJoin: true,
  dumpTrack: -1
});