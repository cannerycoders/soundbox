// Example of Midi probe under scripting control
let probe = await Midi.Probe();
if (probe.devices) // HzWeb
{
  console.log("--- HzWeb MIDI probe -----------");
  console.log("MIDI inputs ------------");
  for (let {name, port, id}of probe.devices.inputs)
    console.log(`  ${name} port:${port}, id: ${id}`);
  console.log("\nMIDI outputs ------------");
  for (let {name, port, id}of probe.devices.outputs)
    console.log(`  ${name} port:${port}, id: ${id}`);
}
else if (probe.midiapis) // Hz/desktop
{
  try
  {
    console.log("--- Hz MIDI probe -----------");
    for (let api of probe.midiapis)
    {
      console.info(`-- ${api.API} ----`);
      console.info(" inputs");
      for (let input of api.inputs)
        console.info(`  ${JSON.stringify(input)}`);
      console.info(" outputs");
      for (let output of api.outputs)
        console.info(`  ${JSON.stringify(output)}`);
    }
  }
  catch (err)
  {
    console.log("midiprobe error " + err);
  }
}
else
    console.warn("midiprobe results: " + JSON.stringify(probe));