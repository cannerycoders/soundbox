// This simple example assumes a MIDI device is present on port 0.
// When invoked, we route notes and other MIDI events to the
// GeneralMIDI plugin.  Note that this simple example supports
// chords, pitch bending, etc.  The cancel trick affords the
// opportunity to "gracefully" shutdown using x in the Fibers Control Panel

console.log("This example requires a MIDI input device.");
let id = `t${this.GetId()}`;
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC()
dac.Show();
let inst = await scene.NewAnode("GeneralMIDI");
inst.Show();
scene.Chain(inst, dac);
await scene.Sync();

let port = 0;
let midiInput = new MidiIn(port);
let ok = await midiInput.Open();
midiInput.verbose = 1;
while(true)
{
  let msg = yield; // allows for external cancellation
  if(msg == "_cancel_") break;
  let data = await midiInput.Recv(); // "blocks" until activity
  midiInput.Perform(inst, data);
}

console.log(`${id} done`);