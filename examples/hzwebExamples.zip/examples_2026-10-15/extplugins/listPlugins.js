console.log(JSON.stringify
  (AnodeRegistry.GetPluginNames(), null, 2));