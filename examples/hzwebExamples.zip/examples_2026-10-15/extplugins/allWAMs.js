
await Aengine.Open();
let wams = AnodeRegistry.GetPluginNames();

let initBlacklist =  [

  // these throw during instantiate
  "Step Sequencer",
  "Video Input",
  "ThreeJS Video Generator",
  "Pedalboard WAC2022",

  // emit warnings
  "React Pedalboard", // can't find all pedals (cf pedals.json)
  "Function Sequencer", // no WAMExtension.collaboration
  "Envelope Follower", // no WAMExtensions.modulationTarget.

  // fail during show
  "Randomizer", 
  "ISF Video Shader",

  // 
  "MIDI Input", // warning... no devices?
  "MIDI Output",
];

// misc:
//  Soundfont-player - Error accessing MIDI devices
//  LiveGain - requires special wiring.

let newBlacklist = [];
for (let wnm of wams)
{
  if (initBlacklist.includes(wnm))continue;
    
    console.log(`try ${wnm} .............`);
    try
    {
      let wamInstance = await Anode.New(wnm);
        wamInstance.Show();
        console.log(`--- success ${wnm} --------`);
    }
    catch (err)
    {
        newBlacklist.push(wnm);
        console.warn("!!!! Fail", wnm, err);
    }
}

console.log("blacklist", 
    JSON.stringify(newBlacklist, null, 2));
