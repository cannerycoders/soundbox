// this example auditions notes from every builtin bank+patch.
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let inst = await Anode.New("Hz.Osc", {
  preset: {
    Waveform: 1,
    Gain: .5,
    A: .1,
    D: .01,
    S: 1,
    R: .04,
  }});
inst.Show();

let rev = await Anode.New("Hz.Freeverb");
rev.Show();

let scope;
scope = await Anode.New("Hz.SpectreScope");
scope.Show();
scene.Chain(inst, scope, rev, dac);

let latency = scene.Seconds(.1);
let start = scene.Now() + latency;
let interval = scene.Seconds(0.2);
let legato = .5;
let nnotes = 20;
let nvariants = 5;
// following order matches the GUI menu order which
// map to the value indices 0-3
let waveforms = ["sine", "square", "sawtooth", "triangle"];
for (let w = 0;w < waveforms.length;w++)
{
  inst.SetParam("Waveform", w, -1, start);
  let waveform = waveforms[w];
  console.log("waveform:" + waveform);
  for (let p = 0;p < nvariants;p++)
  {
    let kbase = 50 + Math.floor(20 * Math.random());
    for (let i = 0;i < nnotes;i++)
    {
      let key = kbase + (i % 12);
      let vel = .7 + .3 * Math.random();
      inst.Note({key, velocity:vel, dur:legato * interval, when:start});
      start += interval;
      await scene.Wait(.98 * interval);
      yield; // allow cancellation of this fiber.
    }
  }
}
await scene.Wait(scene.Seconds(2));
console.log("done");