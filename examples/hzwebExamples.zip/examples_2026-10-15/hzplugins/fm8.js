// this example auditions notes from every builtin bank+patch.
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let inst = await scene.NewAnode("Hz.FM8");
inst.Show();

// these are the original libfmsynth presets:
let preset = globalThis.Random.Choose([
  "angry_overture.json", 
  "clocky.json",            
  "expressive_harp.json",   
  "lead_pad.json",          
  "old_school_organ.json",  
  "retro_sci_fi.json",
  "square_emotions.json"
]);
let presetPath = path.join(this.GetCWD(), `fm8/voices/${preset}`);
let presetObj = await globalThis.FetchWSFile(presetPath, "json");
await inst.LoadPreset(presetObj);

let rev = await scene.NewAnode("Hz.Freeverb");
rev.Show();

let scope;
scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(inst, scope, rev, dac);
await scene.VisualizeGraph(preset.slice(0, -5));

let legato = .5;
let interval = scene.Seconds(.3);
let start = scene.Now();

let keys = MusicTheory.GetScaleKeys("C whole tone", 1, 4);
for (let i = 0;i < 150;i++)
{
  let key = Random.Choose(keys);
  let vel = Random.InRange(.3, 1);
  inst.Note({key, velocity:vel, dur:interval, when:start});
  start += interval * legato;
  await scene.Wait(interval*legato*.99);
  yield;
}

await scene.Wait(scene.Seconds(2));
console.log("done");