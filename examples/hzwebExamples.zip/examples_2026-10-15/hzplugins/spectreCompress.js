//
// Simple example of Hz.SpectreCompress in which compressor thresholds
// are specified in frequency-space-x and dB-space-y.
// 
const {Ascene, path} = globalThis;
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let acfg = {mode: "mono"};

// Mono Samplo
let voice = await scene.NewAnode("Hz.Samplo", {acfg});

// obama.wav measured maxdB: -20 dB.
let files = [path.join(this.GetCWD(), "../wav/obama.wav")];
await voice.LoadPreset({
  instrument: {kit: "Workspace", inst: files}
});
voice.Show();

let spectrecompress = await scene.NewAnode("Hz.SpectreCompress", {
  acfg,
  preset: {
    DownThreshold: -18, 
    RunMode: 1, // 0:pass 1:compress/down, 2:expand/up, 3:both
    DownwardEnv: path.join(this.GetCWD(), "spectre/trivial.knt"),
    // DownwardEnv: path.join(this.GetCWD(), "spectre/compress.knt"),
    // UpwardEnv: path.join(this.GetCWD(), "spectre/expand.knt"),
    ZScale: 10,
  }
});
spectrecompress.Show();

// two scopes to compare raw with processed
let sscope = await scene.NewAnode("Hz.SpectreScope", {name:"processed"});
sscope.Show();

let sscope2 = await scene.NewAnode("Hz.SpectreScope", {name:"raw"});
sscope2.Show();

scene.Chain(voice, spectrecompress, sscope, dac);
scene.Chain(voice, sscope2, scene.GetBlackhole());
scene.VisualizeGraph();
voice.NoteOn(0, 1); // start playing our voice recording

