let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let instrument = {kit: "FatBoy", inst: "vibraphone"};
let instref = `${instrument.kit}/${instrument.inst}`;
    
let samplo = await Anode.New("Hz.Samplo");
samplo.Show();
await samplo.LoadPreset({
  instrument,
  A: .01,
  D: .01,
  S: 1,
  R: 2,
  Gain: 2,
});
scene.Chain(samplo, dac);

let latency = scene.Seconds(.5);
let start = scene.Now() + latency;
let interval = scene.Seconds(.25);
let legato = 1;
let nnotes = 12 * 40;
let kbase = 40 + Math.floor(40 * Math.random());
console.log(`start ${instref} on ${kbase}`);
let loaders = globalThis.AudioFileLoaders;
let loadernames = Object.keys(loaders).filter((k) => k != "Workspace");
for(let i=0;i<nnotes;i++)
{
  let key = kbase + (i%12);
  let vel = 1;
  let now = scene.Now();
  if(start < now)
  {
    console.warn("sample-load lag " + (now - start).toFixed(2));
    start = now + scene.Seconds(.5);
  }
  // note with duration
  samplo.Note({key, velocity:vel, dur:legato*interval, when:start});
  await scene.Wait(interval);
  if(i != 0 && (i % 12) == 0)
  {
    let instrument;
    // select either a VCSL or Soundfile (Sf) instrument.
    let xx = Math.random();
    let lnm = loadernames[Math.floor(xx*loadernames.length)];
    let loader = loaders[lnm];
    if(!loader.RandomInstrument)
      console.warn(`${lnm} doesn't implement RandomInstrument`);
    else
    {
      instrument = (await loader.RandomInstrument()) ?? defInst;
      await samplo.LoadPreset({instrument});
      start += interval;
      instref = `${instrument.kit}/${instrument.inst}`; 
      kbase = 40 + Math.floor(40 * Math.random());
      console.log(`start ${instref} on ${kbase}`);
    }
  }
  start += interval;
  yield;
}
await scene.Wait(scene.Seconds(2));
console.log("done");