// 
// This example runs noise through Hz.Biquad. 
// Tweaking the parameter values produces
// a wide variety of filter effects.
//
let scene = await Ascene.BeginFiber(this); 
let dac = scene.GetDAC();
dac.Show();

let sscope = await scene.NewAnode("Hz.SpectreScope");
sscope.Show();

let inst = await scene.NewAnode("Hz.Noise");
inst.Show();

let filt = await scene.NewAnode("Hz.Biquad");
filt.Show();

scene.Chain(inst, filt, sscope, dac);

inst.NoteOn(30, 1);
