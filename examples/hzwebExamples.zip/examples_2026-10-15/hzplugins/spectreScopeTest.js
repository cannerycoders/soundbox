//
// this example speeps a unity sine wave through a range of frequencies.
// 
let {examples} = await this.Require("./genish/exampleSynths.js");

const {Ascene} = globalThis;
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();
dac.SetParam("Gain", .1);

let genish = await scene.NewAnode("Hz.Genish");
// genish.Show();

let scope = await scene.NewAnode("Hz.Scope", {acfg: {channelCount:1}});
scope.Show();

let sscope;
sscope = await scene.NewAnode("Hz.SpectreScope");
sscope.Show();
scene.Chain(genish, sscope, scope, dac);

globalThis.genishTimeout = 20000; // millis
await genish.LoadPreset({genish: {
  code: examples.mouseSine.toString(),
  wsdir: this.GetCWD()
}});

await scene.Wait(scene.Seconds(2));
console.log("done");