let scene = await Ascene.BeginFiber(this);

// This example shows Hz.Mix running in two modes:
//   "stereo":  input is presumed to be panned, don't mess with it.
//   "1to2": input is either mono or we wish to override the input pan.
// Note that in the first case, there is no "Pan" in the GUI.
// To verify functionality, modify Pan for FM7 and inspect the
// VU meters on the mix nodes.
//
let dac = scene.GetDAC();
dac.Show();

let inst = await scene.NewAnode("Hz.FM7", {preset: {Bank:5}});
inst.Show();

let mix1 = await scene.NewAnode("Hz.Mix", 
{
    acfg:{mode:"1to2"}
});
mix1.Show();

let mix2 = await scene.NewAnode("Hz.Mix", 
{
    acfg:{mode:"stereo"}
});
mix2.Show();

scene.Chain(inst, mix1, scene.GetDAC());
scene.Chain(inst, mix2, scene.GetDAC());

let notes = [45, 50, 54, 57];
let interval = scene.Seconds(.1);
let start = scene.Now();
for (let i = 0;i < 800;i++)
{
  let n = Random.Choose(notes);
  inst.Note(n, .9, interval, start);
  start += interval;
  await scene.Wait(.95 * interval);
}