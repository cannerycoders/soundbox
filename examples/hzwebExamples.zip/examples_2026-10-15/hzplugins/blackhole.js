// An example of the use of Hz.Blackhole:
// ensure scope updates when not connected to DAC.

let scene = await Ascene.BeginFiber(this);
let blackhole = await Anode.New("Hz.Blackhole");
blackhole.Show();

let inst = await Anode.New("Hz.Noise", {
  preset: {
    Waveform: 1,
    Gain: 3,
    A: .5,
    D: .01,
    S: 1,
    R: .5,
  }});
inst.Show();

let scope = await Anode.New("Hz.Scope");
scope.Show();

scene.Chain(inst, scope, blackhole);


const noteDur = scene.Seconds(1);
for (let i = 0;i < 30;i++)
{
  inst.Note(i, Random.InRange(.5, 1), noteDur);
  await scene.Wait(2 * noteDur);
}