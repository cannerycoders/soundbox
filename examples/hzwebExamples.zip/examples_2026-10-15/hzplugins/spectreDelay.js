// Simple example of Hz.Spectre's 
// Gain Envelope feature.  Note that if you view 
// the envelope (spectre/envslide.knt)
// during its performance, the z-slider and 
// visualized/interpolated curve updates as well.
// 
const {Ascene, path} = globalThis;
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let acfg = {mode: "mono"};
let spectre = await scene.NewAnode("Hz.Spectre", {
  acfg,
  preset: {
    // GainEnv: path.join(this.GetCWD(), "spectre/envslide.knt"),
    DelayEnv: path.join(this.GetCWD(), "spectre/envslide.knt"),
    ZScale: 10
  }
});
spectre.Show();

// Mono Samplo
let voice = await scene.NewAnode("Hz.Samplo", {acfg});
let files = [path.join(this.GetCWD(), "../wav/obama.wav")];
await voice.LoadPreset({
  instrument: {kit: "Workspace", inst: files}
});
voice.Show();

let sscope = await scene.NewAnode("Hz.SpectreScope", {name:"spectre"});
sscope.Show();

let sscope2 = await scene.NewAnode("Hz.SpectreScope", {name:"raw"});
sscope2.Show();

scene.Chain(voice, spectre, sscope, dac);
scene.Chain(voice, sscope2, scene.GetBlackhole());
scene.VisualizeGraph();
voice.NoteOn(0, 1); // start playing our voice recording
