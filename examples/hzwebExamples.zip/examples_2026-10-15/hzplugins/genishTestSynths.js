let scene = await Ascene.BeginFiber(this);
let {examples} = await this.Require("./genish/exampleSynths.js");

let dac = scene.GetDAC();
dac.Show();

let genish = await scene.NewAnode("Hz.Genish");
genish.Show();

let scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(genish, scope, dac);

for (let [nm, val]of Object.entries(examples))
{
  if (nm.startsWith("_"))continue;
  console.log(`genish test ${nm} -----------\n` +
      `<pre>${val.toString().replace(/^ {2}/mg, "")}</pre>`);
  await genish.LoadPreset({genish: {
    name: nm,
    code: val.toString(), 
    wsdir: this.GetCWD()
  }});
  await scene.Wait(scene.Seconds(5));
};
