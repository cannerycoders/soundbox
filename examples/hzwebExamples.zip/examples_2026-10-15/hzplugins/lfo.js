// 
// This example of Hz.LFO requires a MIDI device.
// 
// The Keytracking parameter is functional only 
// if/when MIDI events are delived.
//
let scene = await Ascene.BeginFiber(this); 
let dac = scene.GetDAC();
dac.Show();
let inst = await scene.NewAnode("Hz.FM7");
inst.Show();
let lfo = await scene.NewAnode("Hz.LFO");
lfo.Show();

console.log("This example requires a MIDI input device.");

scene.Chain(inst, lfo, dac);

let port = 0;
let midiInput = new MidiIn(port);
let ok = await midiInput.Open();
while(true)
{
  let msg = yield; // allows for external cancellation
  if(msg == "_cancel_") break;
  let data = await midiInput.Recv(); // "blocks" until activity
  midiInput.Perform(inst, data);
  midiInput.Perform(lfo, data);
}