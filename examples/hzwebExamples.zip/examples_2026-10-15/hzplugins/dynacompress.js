//
// This is an example of Hz.WebAudioIn and Hz.DynaCompress
//  NB: webaudio URLs can suffer from connection issues, high latency, CDN hiccups 
//   or become invalid.
//
let scene = await Ascene.BeginFiber(this);
let dac = await scene.NewAnode("Hz.DAC");
dac.Show();

let compressor = await scene.NewAnode("Hz.DynaCompress");
compressor.Show();

let radio = await scene.NewAnode("Hz.WebAudioIn");
radio.Show();

let scope = await scene.NewAnode("Hz.SpectreScope");
scope.Show();

scene.Chain(radio, compressor, scope, dac);

const [url, name] = ["https://ice8.securenetsystems.net/KVSH1019", "Vashon Island, WA USA"];
await radio.LoadPreset({
  Station: name,
  URL: url,
  Gain: 1, // large to ensure compressor activates
});

console.log("Audition your changes the the dynamics compressor.");