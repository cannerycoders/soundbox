// This is an example of Hz.AudioIn.
// When run, it attempts to open the default audio input device (ie microphone) 
// on your computer.  If it finds and is granted access to the input device 
// the signal is routed through the scope and Echo (to prevent potenial nasty feedback).
// 
let scene = await Ascene.BeginFiber(this); 

let dac = await scene.NewAnode("Hz.DAC");
dac.Show();

let mic = await scene.NewAnode("Hz.AudioIn");
mic.Show();

let scope = await scene.NewAnode("Hz.Scope", {acfg: {channelCount:1}});
scope.Show();

let echo = await scene.NewAnode("Hz.Echo");
echo.Show();

scene.Chain(mic, scope, echo, dac);
