// 
// This example of Hz.LFO requires a MIDI device.
// 
// The Keytracking parameter is functional only 
// if/when MIDI events are delived.
//
console.log("This example requires a MIDI input device.");
console.log(`FM8 NB: 
PitchWheel works on most/all patches.
Modwheel depends on non-zero Op ModWheel Sensitivity.`);

let scene = await Ascene.BeginFiber(this); 
let dac = scene.GetDAC();
dac.Show();
let inst = await scene.NewAnode("Hz.FM8");
inst.Show();

await inst.LoadPreset("shuffle");

scene.Chain(inst, dac);

let port = 0;
let midiInput = new MidiIn(port);
let ok = await midiInput.Open();
while(true)
{
  let msg = yield; // allows for external cancellation
  if(msg == "_cancel_") break;
  let data = await midiInput.Recv(); // "blocks" until activity
  midiInput.Perform(inst, data);
}