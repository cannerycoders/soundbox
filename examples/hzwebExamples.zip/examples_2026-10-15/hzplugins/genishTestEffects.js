let scene = await Ascene.BeginFiber(this);
let {examples} = await this.Require("./genish/exampleEffects.js");

let dac = scene.GetDAC();
dac.Show();

let inst = await scene.NewAnode("Hz.Osc", {
  acfg: {mode: "stereo"},
  preset:{Waveform: 0}
});

let genish = await scene.NewAnode("Hz.Genish", {acfg:{type:"effect"}});

let scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(inst, genish, scope, dac);

let [noteid] = inst.NoteOn(35, 1);
let interval = scene.Seconds(.1);
for (let [nm, val]of Object.entries(examples))
{
  console.log(`genish test ${nm} -----------\n` +
      `<pre>${val.toString().replace(/^ {2}/mg, "")}</pre>`);  
  await genish.LoadPreset({genish: {
    name: nm,
    code: val.toString(), 
    wsdir: this.GetCWD()
  }});
  // 100 different settings for our single note.
  for (let i = 0;i < 100;i++)
  {
    await scene.Wait(interval);
    inst.NoteExpression("_frequency", Random.InRange(100, 500), 0, noteid);
    inst.NoteExpression("expression", Random.InRange(.2, 1), 0, noteid);
    inst.NoteExpression("pan", Random.InRange(0, 1), 0, noteid);
  }
};

inst.NoteOff(35, 1);