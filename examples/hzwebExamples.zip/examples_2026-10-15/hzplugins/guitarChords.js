// This example of Hz.Guitar shows how to request and perform
// guitar chords.
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
const eventHub = globalThis.EventHub;
dac.Show();

let inst = await scene.NewAnode("Hz.Guitar");
let guitarId = inst.GetId();
inst.Show();

let effects = await scene.NewAnode("Hz.Effects");
effects.Show();

scene.Chain(inst, effects, dac);

let legato = 1.2; // for chords, should be > 1
let interval = scene.Seconds(.75);
let start = scene.Now();
let lastfrets = null;
let updown = [-1, 1];
for(let pnm of MusicTheory.GetChordProgressionNames())
{
  console.log("\nProgression: " + pnm);
  let chords = MusicTheory.GetChordProgressionChords(pnm);
  let dir = -1; // up
  for(let cnm of chords)
  {
    let nextfrets = MusicTheory.GetGuitarChordFrets(cnm);
    if(lastfrets)
    {
      // nb: squeaks are emitted only when a hand movement
      //  is detected on the same *wound* string.
      // Here we provide a gain ot 5 to highlght the few
      // that may appear. 
      eventHub.Emit("Hz.Guitar", guitarId,  "handmove", 
        start - .1, lastfrets, nextfrets, 5);
    }
    dir = Random.Choose(updown);
    console.log(cnm + (dir > 0 ? " down" : " up"));
    eventHub.Emit("Hz.Guitar", guitarId, "strum", 
        start, nextfrets, .8, dir);
    start += interval * legato;
    lastfrets = nextfrets;
    await scene.Wait(interval*legato*.99);
    yield;
  }
}
await scene.Wait(scene.Seconds(2));
eventHub.Emit("Hz.Guitar", guitarId, "muteall");
