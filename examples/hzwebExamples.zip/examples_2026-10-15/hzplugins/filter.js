// 
// This example runs Hz.Filter through some paces. Notes are provided
// by a MIDI controller.
//   * Choose between Lowpass, Highpass, Bandpass and Notch
//   * Choose 1 or 2 stages
//   * Enabling Key Tracking causes the filter to follow the MIDI notes played.
//     Note that this requires that MIDI events are delivered to both 
//     instrument and filter.  The Offset param is measured in semitones
//     around the tracked note.
//   * Enabling LFO causes the filter frequency value to be modulated by
//     the selected function.  This can be set to an arbitrary value during
//     initialization (via LoadPreset).  You can also use the Shape menu.
//     LFORate is measured in Hz and controls the speed of the modulation.
//     LFORange is measured in semitones and controls the depth of modulation.
//     When key tracking is disabled the LFO operates in free-running mode
//     but when enabled the Loop LFO controls whether the lfo repeats or
//     only triggers once.
//
let scene = await Ascene.BeginFiber(this); 
let dac = scene.GetDAC();
dac.Show();
let inst = await scene.NewAnode("Hz.FM7");
inst.Show();

console.log("play notes on your MIDI device.");

// a knot is t,value,power, 
// t,value range 0-1, 
// power [-5,5], last power ignored
const envelopes = [
  {
    shape: "sine", 
    smooth: true,
    data: [0,0,0, 0.5,1,0, 1,0,0]
  },
  {
    shape: "tooth",
    smooth: false,
    data: [0,0,5, 0.5,1,-5, 1,0,0]
  },
  {
    shape: "fadeup",
    smooth: false,
    data: [0,0,5, 1,1,0]
  }
];
let envelope = envelopes[0];
let filt = await scene.NewAnode("Hz.Filter", {preset: {
  LFO: 1, 
  LFORate: 4,
  Resonance: .7,
}});
await filt.LoadPreset({envelope});
filt.Show();

scene.Chain(inst, filt, dac);

let port = 0;
let midiInput = new MidiIn(port);
let ok = await midiInput.Open();
while(true)
{
  let msg = yield; // allows for external cancellation
  if(msg == "_cancel_") break;
  let data = await midiInput.Recv(); // "blocks" until activity
  midiInput.Perform(inst, data);
  midiInput.Perform(filt, data);
}