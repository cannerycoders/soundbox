// This is an another example of Hz.AudioIn, this time coupled with 
// Hz.Tuner and Hz.Waveshaper.
// 
// If your computer has a USB audio interface, it's possible to route
// your guitar through the interface, then use Hz.Tuner to ensure you're in tune.
// Next you can route your guitar signal to distortion or other effects 
// (here, simple overdrive) and voila you have a guitar studio.  For
// the case of an M-Audio air audio interface, the guitar is on the 
// second channel (Channel 1).
//
// NB: potential failure conditions include:
//  - you don't have an audio input device
//  - your audio input is single channel
//  - your guitar isn't on channel 1
//  - your input device can also "hear" your speakers, 
//    this can produce nasty feedback (watch out!)
// 
let scene = await Ascene.BeginFiber(this); 

let dac = await scene.NewAnode("Hz.DAC", {preset:{Gain:.5}});
dac.Show();

let audioIn = await scene.NewAnode("Hz.AudioIn", {preset:{Channel:1}});
audioIn.Show();

let tuner = await scene.NewAnode("Hz.Tuner");
tuner.Show();

let overdrive = await scene.NewAnode("Hz.Waveshaper", 
                  {preset:{InputGain:2, Drive:1, OutputGain:.5}});
overdrive.Show();

let scope = await scene.NewAnode("Hz.Scope", {acfg: {channelCount:1}});
scope.Show();

scene.Chain(audioIn, tuner, overdrive, scope, dac);
