let scene = await Ascene.BeginFiber(this); 
let dac = await scene.NewAnode("Hz.DAC");
dac.Show();

let inst = await scene.NewAnode("Hz.FM7");
inst.Show();

let echo = await scene.NewAnode("Hz.Echo");
await echo.LoadPreset({
  Delay:1.75,
  DelayMax:5, 
  Wet: 1, 
  Dry: 1, 
  Feedback:.35, 
  PingPong: 1,
  Mode: 1,
  FilterCutoff:800,
  FilterQ: 2,
});
echo.Show();

let scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(inst, echo, scope, dac);
scene.VisualizeGraph();

let latency = scene.Seconds(.5);
let start = scene.Now() + latency;
let interval = scene.Seconds(1);
let legato = .5;
let nnotes = 20;
let nprogs = 5;
let nbanks = 3;
let scaleFn = Tonal.Scale.steps("C3 leading whole tone");
for(let b=0;b<nbanks;b++)
{
  // console.log(`bank ${b}`);
  inst.SetParam("Bank", b, -1, start);
  for(let p=0;p<nprogs;p++)
  {
    // console.log(`patch ${p}`);
    inst.SetParam("Patch", p, -1, start);
    for (let i = 0;i < nnotes;i++)
    {
      let now = scene.Now();
      let key = Tonal.Note.midi(scaleFn(Math.floor(Random.InRange(0, 24))));
      // console.log(`key: ${key} start: ${start.toFixed(2)} now: ${now.toFixed(2)}`);
      let vel = .7; // .7 + .3 * Math.random();
      inst.Note({key, velocity:vel, dur:legato * interval, when:start});
      start += interval;
      await scene.Wait(.9 * interval);
      yield; // allow cancellation of this fiber.
    }
  }
}

await scene.Wait(scene.Seconds(4));
console.log("done");
