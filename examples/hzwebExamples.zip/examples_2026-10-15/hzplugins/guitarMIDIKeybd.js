// This simple example assumes a MIDI device is present on port 0.
// When invoked, we route notes and other MIDI events to the
// Hz.Guitar plugin.  
//
// Note that this simple example supports chords and pitch bending. 
//

console.log("This example requires a MIDI input device.");
let id = `t${this.GetId()}`;
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC()
dac.Show();
let inst = await scene.NewAnode("Hz.Guitar");
inst.Show();
let fx = await scene.NewAnode("Hz.Effects");
fx.Show();
scene.Chain(inst, fx, dac);

let port = 0;
let midiInput = new MidiIn(port);
let ok = await midiInput.Open();
midiInput.verbose = 1;
while(true)
{
  let msg = yield; // allows for external cancellation
  if(msg == "_cancel_") break;
  let data = await midiInput.Recv(); // "blocks" until activity
  midiInput.Perform(inst, data);
}

console.log(`${id} done`);