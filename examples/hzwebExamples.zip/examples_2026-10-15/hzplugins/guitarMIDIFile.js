// this example shows Hz.Guitar in a MIDI file performance.

let iperf = Random.Choose(["bach", "lotus"]); // select bach or lotus
let performance = {
  bach: {f: "Bach_Cantate_BWV20.mid",  // two tracks, format 1.
    speed: 1, 
    gain: 1, 
    trackProgs: ["guitar", "guitar"],
  }, 
  lotus: {f: "lotus.mid",  // lotus.mid has 7 tracks, format 1
    speed: 1, 
    gain: 1,  
    trackProgs: [null, 
      null, // 49, // drone
      81, // ocarina (square)
      null, // "percussion", 
      null, // "percussion", 
      "guitar", 
      "guitar"],
  },
}[iperf];

console.log("loading " + performance.f + "...");
const {f, programs, speed, gain, trackProgs, R} = performance;
let uri = path.join(this.GetCWD(), "../midi/midifiles", f);
let midiFile = new MidiFile();
let err = await midiFile.Load(uri);
console.log(`loading done, found ${midiFile.GetNumTracks()} tracks`);
if(err) return;

// Start up audio engine with reverb effect.
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();
await dac.LoadPreset({Gain: gain});
let guitar = await scene.NewAnode("Hz.Guitar");
guitar.Show();

let fx = await scene.NewAnode("Hz.Effects");
scene.Chain(fx, dac);
fx.Show();

scene.Chain(guitar, fx);

// create instruments, associated with either track or channel.
let progs = trackProgs?.length ? trackProgs : channelProgs;
let mode = trackProgs?.length ? "Track" : "Chan";
let handlers = [];;
for(let i=0;i<progs.length;i++)
{
  let prog = progs[i];
  if(prog != null)
  {
    if(prog != "guitar")
    {
      let inst = await scene.NewAnode("GeneralMIDI", {
        name: `${mode}${i}`,
        preset: {
          presetName:prog,
          R: R ?? .1,
          Gain: 2.0
        }});
      handlers.push(inst);
      inst.Show();
      scene.Chain(inst, dac);
    }
    else
      handlers.push(guitar);
  }
  else
    handlers.push(null);
}

class MyNH extends NoteHandler
{
  constructor(handlers, mode)
  {
    super();
    this.debug = false;
    this.handlers = handlers;
    this.mode = mode; // track or chan
    this.track = 0;
    if(mode == "Track")
      this.getInst = this.getTrackInst;
    else
      this.getInst = this.getChanInst;
  }

  SetTrack(trk)
  {
    if(this.track != trk) { this.track = trk; }
  }
    
  SetChannel(chan)
  {
    if(this.chan != chan)
    {
      // console.log("Set Chan " + chan);
      this.chan = chan;
    }
  }
    
  NoteOn(key, velpct, etime)
  {
    let inst = this.getInst(this.chan);
    if(inst)
    {
      // console.log(`NoteOn.${this.chan}`, key, etime.toFixed(2));
      inst.NoteOn(key, velpct, etime);
    }
    else
    if(this.debug)
      console.log(`NoteOn.${this.chan} ignoring`, key, etime.toFixed(2));
  }
    
  NoteOff(key, velpct, etime)
  {
    let inst = this.getInst(this.chan);
    if(inst)
      this.getInst(this.chan).NoteOff(key, velpct, etime);
  }
    
  MidiEvent(msg, etime)
  {
    let ich = msg[0] & 0x0F;
    let inst = this.getInst(ich);
    if(inst)
    {
      // console.log("MidiEvent", msg);
      // this.getInst(ich)?.MidiEvent(msg, etime);
    }
  }

  getTrackInst()
  {
    return this.handlers[this.track];
  }
    
  getChanInst(chan)
  {
    return this.handlers[chan % this.handlers.length];
  }
} // end MyNH

let masterhandler = new MyNH(handlers, mode);

// establish midi performance configurations
// nb: to diagnose issues, we can also perform a single track
performance.programMapper = []; // key is chan, value is prog
let cfg =
{
  speed,   
  setTempo: "once", // "once" | "never" | "always" 
  programChange: "allow",
  programMapper: function(prog, trk, chan)
  {
    performance.programMapper[chan] = prog;
    console.log(`track:${trk} chan:${chan} prog:${prog} `);
    return prog;
  },
  dumpTrack: null, // -1 means all, null means none, otherwise a track
  dumpJoin: true
};
if(cfg.dumpTrack != null)
  midiFile.Dump(cfg);
    
// this is where it all happens -----------------------------------------
console.log(`${f} has ${midiFile.GetNumTracks()} tracks, format ${midiFile.GetFormat()}`);
for await (const val of midiFile.Perform(scene, masterhandler, .5, cfg))
{
  yield;
}
