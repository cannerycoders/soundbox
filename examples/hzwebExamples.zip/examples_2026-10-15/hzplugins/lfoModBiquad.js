// 
// This example runs Hz.LFO as a parameter modulator. 
// Here we drive FM7's Pan and Biquad's Frequency.
// Remember only *some* parameters of your target node 
// may be modulatable.  This is nodetype-dependant 
// so YMMV.
//
let scene = await Ascene.BeginFiber(this); 
let dac = scene.GetDAC();
dac.Show();

let inst = await scene.NewAnode("Hz.FM7", {
  preset: {
    Bank: 2,
    Patch: 2
  }
});
inst.Show();

let biquad = await scene.NewAnode("Hz.Biquad", {
  preset: {
    Type: 2, // bandpass
    Resonance: 24,
  }
});
biquad.Show();

let lfo1 = await scene.NewAnode("Hz.LFO", {
  name: "pan",
  preset: {
    RunMode: 1, /* generator, not modulator */
    OutMin: -.5,
    OutMax: .5,
    Rate: 1,
  }
});
lfo1.Show();

let lfo2 = await scene.NewAnode("Hz.LFO", {
  name: "filter",
  preset: {
    RunMode: 1, /* generator, not modulator */
    OutMin: -300, // 600 hz frequency range
    OutMax: 300,
    Rate: 2,
    envelope: {
      shape: "tooth",
      smooth: true,
      data: [0, 0, 5, 0.5, 1, -5, 1, 0, 0]
    },
  }
});
lfo2.Show();

scene.Chain(inst, biquad, dac);
scene.ModulateParam(lfo1, inst, "Pan");
scene.ModulateParam(lfo2, biquad, "Frequency");

await scene.VisualizeGraph();

let notes = [55, 60, 64, 67];
let interval = scene.Seconds(.1);
let start = scene.Now();
for (let i = 0;i < 400;i++)
{
  let n = Random.Choose(notes);
  inst.Note(n, .9, interval, start);
  start += interval;
  await scene.Wait(.95 * interval);
}
