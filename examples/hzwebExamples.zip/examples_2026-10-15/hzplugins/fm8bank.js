// This example auditions notes from each preset found in the named file..
// Presets were generated and named by AI: ChatGPT, Claude, Gemini and purport 
// to capture a wide range of configurations. YMMV.
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let inst = await scene.NewAnode("Hz.FM8");
inst.Show();

let rev = await scene.NewAnode("Hz.Freeverb");
rev.Show();

let scope;
scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(inst, scope, rev, dac);
scene.VisualizeGraph("FM8");

let presetPath = path.join(this.GetCWD(), "fm8/banks/chatgpt32.json");
let presetObj = await globalThis.FetchWSFile(presetPath, "json");

for(let k in presetObj)
{
  console.log(`preset:${k}`);
  await inst.LoadPreset(presetObj[k]);

  let legato = .5;
  let interval = scene.Seconds(.25);
  let start = scene.Now();

  let keys = MusicTheory.GetScaleKeys("C whole tone", 2, 4);
  for (let i = 0;i < 100;i++)
  {
    let key = Random.Choose(keys);
    let vel = Random.InRange(.3, 1);
    inst.Note({key, velocity:vel, dur:interval, when:start});
    start += interval * legato;
    await scene.Wait(interval*legato*.99);
    yield;
  }
}

await scene.Wait(scene.Seconds(2));
console.log("done");