// This example allows you to explore Hz.StretchSS's 
// pitch-shifting and time-stretching features.
// Please read reference/hzplugins for caveats regarding
// the limits of time-stretching a live input signal.

const {Ascene, path} = globalThis;
let scene = await Ascene.BeginFiber(this);
let dac = await scene.GetDAC();
dac.Show();

// Mono Samplo
let voice = await scene.NewAnode("Hz.Samplo", {
  acfg: {mode: "stereo"} // vs "mono"
});
let files = [path.join(this.GetCWD(), "../wav/obama.wav")];
await voice.LoadPreset({
  instrument: {kit: "Workspace", inst: files}
});
voice.Show();

let stretch = await scene.NewAnode("Hz.StretchSS");
stretch.Show();

let scope = await scene.NewAnode("Hz.Scope", {acfg:{mode:"stereo"}});
scope.Show();

scene.Chain(voice, stretch, scope, dac);

await scene.VisualizeGraph();

voice.NoteOn(0, 1); // start playing our voice recording

await scene.Wait(scene.Seconds(2));

