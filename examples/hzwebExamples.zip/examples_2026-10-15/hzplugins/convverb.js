let scene = await Ascene.BeginFiber(this); 
let dac = await scene.NewAnode("Hz.DAC");
dac.Show();

let inst = await scene.NewAnode("Hz.FM7");
inst.Show();

// let dist = await scene.NewAnode("Hz.Waveshaper");
// dist.Show();

let rev = await scene.NewAnode("Hz.ConvVerb");
await rev.LoadPreset({Wet: 1, Dry: .2});
rev.Show();

let scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(inst, rev, scope, dac);
scene.VisualizeGraph();

// samples: CC-BY-SA (C) 2016 Damo
let root = "https://raw.githubusercontent.com/zamaudio/impulses/master";
let irlist = [ 
  `${root}/Hall_mono0.wav`,
  `${root}/Hall_mono1.wav`,
  `${root}/Hall_stereo0.wav`,
  `${root}/Hall_stereo1.wav`,
  `${root}/Hall_stereo2.wav`,
  `${root}/Hall_stereo3.wav`,
  `${root}/Hall_truestereo0.wav`,
  `${root}/Hall_truestereo1.wav`,
  `${root}/Plate_mono0.wav`,
  `${root}/Plate_mono1.wav`,
  `${root}/Plate_stereo0.wav`,
  `${root}/Plate_stereo1.wav`,
  `${root}/Plate_truestereo0.wav`,
  `${root}/Room_mono0.wav`,
  `${root}/Room_mono1.wav`,
  `${root}/Room_stereo0.wav`,
  `${root}/Room_stereo1.wav`,
  `${root}/Room_stereo2.wav`,
  `${root}/Room_truestereo0.wav`,
  `${root}/Room_truestereo1.wav`,
  `${root}/Studio_mono0.wav`,
  `${root}/Studio_mono1.wav`,
  `${root}/Studio_stereo0.wav`,
  `${root}/Studio_stereo1.wav`,
  `${root}/Studio_stereo2.wav`,
  `${root}/Studio_truestereo0.wav`,
  `${root}/Studio_truestereo1.wav`,
];

let latency = scene.Seconds(.5);
let start = scene.Now() + latency;
let interval = scene.Seconds(0.2);
let legato = .5;
let nnotes = 20;
let nprogs = 5;
let nbanks = 33;
for (let ir = 0;ir < irlist.length+1;ir++)
{
  if(ir > 1)
  {
    await rev.LoadPreset({impulseResponse: irlist[ir-1]});
  }
  let kbase = 50 + Math.floor(20 * Math.random());
  for (let i = 0;i < nnotes;i++)
  {
    // inst.SetParam("Pan", Math.random());
    let key = kbase + (i % 12);
    let vel = .7 + .3 * Math.random();
    let now = scene.Now();
    inst.Note({key, velocity:vel, dur:legato * interval, when:start});
    start += interval;
    await scene.Wait(.9 * interval);
    yield; // allow cancellation of this fiber.
  }
}
await scene.Wait(scene.Seconds(2));
console.log("done");
