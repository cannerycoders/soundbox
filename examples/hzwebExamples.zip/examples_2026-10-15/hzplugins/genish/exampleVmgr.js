let oneVoice = // indented for pretty console.logging.
`
    function oneVoice(g)
    {
      let freq = g.param(120 + 120 * Math.random());
      let vel = g.param(.8);
      let a = (0.1 + 0.2 * Math.random());
      let d = (.01 + .04 * Math.random());
      let s = .8;
      let r = (.1 + .8 * Math.random());
      let env = g.adsr(a, d, s, r);
      let monosynth = g.mul(vel, g.mul(env, g.cycle(freq)));
      return g.voice(monosynth, {
        _triggers: {
          onoff: [{idx: env.getTriggerIdx()}],
          velocity: [{idx: vel.getValueIdx()}],
          frequency: [{idx: freq.getValueIdx()}],
        },
        // only needed if user wishes to modify envelope params.
        A: {idx: env.getParamPokeIdx("_attack"), unit:"timecoeff"},
        D: {idx: env.getParamPokeIdx("_decay"), unit:"timecoeff"},
        S: {idx: env.getParamPokeIdx("_sustain")},
        R: {idx: env.getParamPokeIdx("_release"), unit:"timecoeff"},
      });
    }`;

exports.examples =
{
  testManual: `
  function(g)
  {
    ${oneVoice}
    
    const N = 5;
    let voices = [];
    // nb: per-voice gain and pan are owned by vmgr.
    // each voice's gain is initialized to 1/(nvoices-1)
    for (let i = 0;i < N;i++)
    {
      voices.push(oneVoice(g));
    }

    // nb: by explicitly triggering an individual voice
    //  we're not validating the dynamic assignment 
    //  feature here.
    console.log("Prescheduled voice+notes ------");
    let vmgr = g.voicemgr({voices});
    let t = 1.5, dur = 1.5;
    const nloops = 10;
    for (let i = 0;i < nloops;i++)
    {
      for (let j = 0;j < N;j++)
      {
        let voice = voices[j];
        const start = t + j * 1;
        const stop = start + dur + .2 * Math.random();
        const vel = .5 + Math.random() * .5;
        const freq = 100 + 300 * Math.random();
        voice.triggerWhen(-start, vel, freq);
        voice.releaseWhen(-stop);
      }
      t += N * 2;
    }
    return vmgr;
  }`,

  testManaged: `
  function(g)
  {
    ${oneVoice}
    
    const N = 5;
    let voices = [];
    // nb: each voice's gain is initialized to 1/(nvoices-1)

    // vmgr supports sampling registered params upon voice assignment.
    // vmgr builtins are VGain and VPan. A synth can support custom
    // per-voice params by 
    //  1. creating a global param (like "VGain")
    //  2. adding the per-voice, per-param ParamPokeIdx as below.
    //    Note that by adding registered (named) params these values
    //    take precedence over the constructor params for eg adsr()
    // 
    g.param(.25, "VGain", {min:0, max:1, default:.25});
    g.param(.5, "VPan", {min:0, max:1, default:.5});
    g.param(.2, "A", {min:.01, max:5, default:.2});  // seconds
    g.param(.5, "D", {min:0, max:5, default:.5}); // seconds
    g.param(.8, "S", {min:0, max:1, default:.8});
    g.param(.5, "R", {min:0, max:5, default:.5}); // seconds

    for (let i = 0;i < N;i++)
    {
      voices.push(oneVoice(g));
    }

    console.log("Dynamically assigned voice+notes ------");
    // nb: by requesting vmgr to assign the note
    //  we are validating dynamic assignment.
    let vmgr = g.voicemgr({voices});
    let t = 1.5, dur = 1.5;
    const nloops = 10;
    for (let i = 0;i < nloops;i++)
    {
      for (let j = 0;j < N;j++)
      {
        const start = t + j * 1;
        const stop = start + dur + .2 * Math.random();
        const vel = .5 + Math.random() * .5;
        const freq = 100 + 300 * Math.random();
        const voiceId = vmgr.triggerWhen(-start, vel, freq);
        vmgr.releaseWhen(-stop, voiceId);
      }
      t += N * 2;
    }
    return vmgr;
  }`,

  voicemgrInit:`
  function(g)
  {
    ${oneVoice}
    
    g.param(.25, "VGain", {min:0, max:1, default:.25});
    g.param(.5, "VPan", {min:0, max:1, default:.5});
    g.param(.2, "A", {min:.01, max:5, default:.2});  // seconds
    g.param(.5, "D", {min:0, max:5, default:.5}); // seconds
    g.param(.8, "S", {min:0, max:1, default:.8});
    g.param(.5, "R", {min:0, max:5, default:.5}); // seconds
    
    // this example initializes voice mgr with a trivial monosynth
    // then leaves in a state to receive Hz note/midi events.
    const N = 128;
    let voices = [];
    // nb: each voice's gain is initialized to 1/(nvoices-1)
    for (let i = 0;i < N;i++)
    {
      voices.push(oneVoice(g));
    }
    // nb: here we leave voicemgr in quiescent state,
    //  waiting for notes.
    return g.voicemgr({voices});
  }`,
  
  fm2: function(g, nvoices = 20) 
  {
    // 1. create an array of voices. 
    // 2. provide them to voicemgr. 
    //
    // Each voice has a standard interface required by voicemgr
    // for any monosynth graph: its triggers and its parameters.
    // Note that your voice can have its own genish parameters
    // but that these don't make their way into the standard
    // Hz.Genish GUI.  You'll need to write your own via
    // Sandbox GUI widgets or other hand-rolled solution.
    //
    function oneVoice(g)
    {
      let freq = g.param(0);
      let harmonicity = g.param(0);
      let modIndex = g.param(0);
      // A ~= 2 ^ ((0-99)/8), to produce a range of 0-<20
      let env = g.adsr(0, 0, 0, 0);
      let modEnv = g.adsr(0, 0, 0, 0);
      let modFreq = g.mul(freq, harmonicity);
      // let modAmount = g.mul(modIndex, modFreq);
      let modOsc = g.cycle(modFreq);
      let fm = g.add(freq, g.mul3(modEnv, modIndex, modOsc));
      let osc = g.sin(fm);
      let velocity = .8; // not a param, so more efficiently triggered.
      let monosynth = g.mul3(env, osc, velocity);
      return g.voice(monosynth,
      {
        _triggers: {
          onoff: [
            {idx: env.getTriggerIdx()},
            {idx: modEnv.getTriggerIdx()},
          ],
          frequency: [
            {idx: freq.getValueIdx()},
          ],
          velocity: [
            {idx: monosynth.getParamPokeIdx("2")},
          ]
        },
        A: {idx: env.getParamPokeIdx("_attack"), unit:"timecoeff"},
        D: {idx: env.getParamPokeIdx("_decay"), unit:"timecoeff"},
        S: {idx: env.getParamPokeIdx("_sustain")},
        R: {idx: env.getParamPokeIdx("_release"), unit:"timecoeff"},
  
        // FM
        Harmonicity: {idx: harmonicity.getValueIdx()},
        ModIndex: {idx: modIndex.getValueIdx()},
        ModA: {idx: modEnv.getParamPokeIdx("_attack"), unit:"timecoeff"},
        ModD: {idx: modEnv.getParamPokeIdx("_decay"), unit:"timecoeff"},
        ModS: {idx: modEnv.getParamPokeIdx("_sustain")},
        ModR: {idx: modEnv.getParamPokeIdx("_release"), unit:"timecoeff"},
      }); 
    }

    let voices = [];
    g.param(.25, "VGain", {min:0, max:1, default:.25});
    g.param(.5, "VPan", {min:0, max:1, default:.5});
    g.param(.2, "A", {min:.01, max:5, default:.2, 
            group:"Env", groupbgd:"#321"});  // seconds
    g.param(.5, "D", {min:0, max:5, default:.5, group:"Env"}); // seconds
    g.param(.8, "S", {min:0, max:1, default:.8, group:"Env"});
    g.param(.5, "R", {min:0, max:5, default:.5, group:"Env"}); // seconds
    g.param(3, "Harmonicity", {
      label:"Ratio", delta: .1, max: 10, min: .1, 
      default: 3, group: "FM", groupbgd: "rgb(17, 44, 34)"});
    g.param(5, "ModIndex", {delta: .1, max: 20, min: .1, default: 5, group: "FM"});
    g.param(.4, "ModA", {delta:.05, min:.01, max: 10, default: .4, group:"FM"});
    g.param(.1, "ModD", {delta:.05, max: 10, group:"FM"});
    g.param(1, "ModS", {min:0, max:1, default:1, group:"FM"});
    g.param(.5, "ModR", {min:0, max:5, default:.5, group:"FM"});
    for (let i = 0;i < nvoices;i++)
      voices.push(oneVoice(g));
    return g.voicemgr({voices});
  },
};