let scene = await Ascene.BeginFiber(this);
let {examples} = await this.Require("./exampleSynths.js");

let dac = scene.GetDAC();
dac.Show();

let genish = await scene.NewAnode("Hz.Genish");
genish.Show();

let scope = await scene.NewAnode("Hz.Scope");
scope.Show();

let sscope = await scene.NewAnode("Hz.SpectreScope");
sscope.Show();
scene.Chain(genish, scope, sscope, dac);

for (let nm of ["sinGlitchFilt"])
{
  let val = examples[nm];
  console.log(`genish test ${nm} ---\n<pre>${val.toString()}</pre>`);
  await genish.LoadPreset({genish: {
    code: val.toString(), 
    wsdir: this.GetCWD()
  }});
  await scene.Wait(scene.Seconds(5));
};
