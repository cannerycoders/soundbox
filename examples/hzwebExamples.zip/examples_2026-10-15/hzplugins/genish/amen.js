let scene = await Ascene.BeginFiber(this);

let dac = scene.GetDAC();
dac.Show();

let genish = await scene.NewAnode("Hz.Genish");

let scope = await scene.NewAnode("Hz.Scope");
if (scope)
{
  scope.Show();
  scene.Chain(genish, scope, dac);
}
else
  scene.Chain(genish, dac);

const amenref = `"${this.GetCWD()}/amen.wav"`;
const amenfn = `
function (g)
{
  return g.data(${amenref})
  .then((d) => 
  {
    // get a randomized playback rate via sah. Tne value will be used
    // to drive a phasor index into peek; this means the value will be
    // in Hz. That is, a value of .25 means the entire sample,
    // irrespective of length, will be played in four seconds.
    let randsig = g.sah(g.mul(g.rand(), .25), g.rand(11), .985);
    return g.mul(g.peek(d, g.phasor(randsig), "floor"), .25); 
  });
}`;

await genish.LoadPreset({genish: {code: amenfn.toString()}});
await scene.Wait(scene.Seconds(5));

