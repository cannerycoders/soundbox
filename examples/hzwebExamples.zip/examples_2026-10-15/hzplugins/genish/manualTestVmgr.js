let scene = await Ascene.BeginFiber(this);
let {examples} = await this.Require("./exampleVmgr.js");

let dac = scene.GetDAC();
dac.Show();

let genish = await scene.NewAnode("Hz.Genish");
genish.Show();

let scope = await scene.NewAnode("Hz.Scope");
scope.Show();

let sscope = await scene.NewAnode("Hz.SpectreScope");
sscope.Show();
scene.Chain(genish, scope, sscope, dac);

for (let nm of ["voicemgrInit"])
{
  let val = examples[nm];
  console.log(`genish test ${nm} -----------\n<pre>${val.toString().replace(/^ {2}/mg, "")}</pre>`);
  await genish.LoadPreset({genish: {
    code: val.toString(), 
    wsdir: this.GetCWD()
  }});
  if (nm != "voicemgrInit")
    await scene.Wait(scene.Seconds(15));
  else
  {
    let interval = scene.Seconds(.3);
    let start = scene.Now();
    let keys = MusicTheory.GetScaleKeys("C gypsy", 2, 4);
    for (let i = 0;i < 150;i++)
    {
      let key = Random.Choose(keys);
      let vel = Random.InRange(.3, 1);
      genish.Note({key, velocity:vel, dur:interval, when:start});
      start += .98 * interval;
    }
  }
};
