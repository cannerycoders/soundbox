// NB: this file isn't intended for direct execution. Rather
//  it is Required by ../genish.js.
// 
// Most of these examples are derived from the genish.js playground.
//  see: https://charlie-roberts.com/genish/playground/index.html
//  notes: mods made for our variant of genish.
// 
//  NB: bound context variables - don't work:
//    the code for these function execute in another context. Functions
//    are serialized and that process drops all closure captures.
//    The workaround: if you need bound variables you can provide
//    the pre-serialized (string) representation.
//
const dir = __dirname ?? ".";
const amenref = `"${dir}/amen.wav"`;

exports.examples =
{
  silence: function(g)
  {
    return g.add(0, 0);
  },
  
  silence2: function(g)
  {
    return [g.add(0, 0), g.add(0, 0)];
  },
  
  cycle: function(g)
  {
    return g.mul(g.cycle(120), 0.2);
  },

  cycle2: function(g)
  {
    return [g.mul(g.cycle(100), .5), 
            g.mul(g.cycle(105), .5)];
  },

  phasor: function(g)
  {
    return g.mul(g.sub(g.phasor(330), .5), 0.3);
  },

  phasor2: function(g)
  {
    return [g.mul(g.sub(g.phasor(330), .5), 0.3), 
            g.mul(g.sub(g.phasor(200), .5), .3)];
  },
  
  sawwave: function(g)
  {
    return g.mul(g.sawwave(330), 0.3);
  },

  sawwave2: function(g)
  {
    return [g.mul(g.sawwave(330), 0.3),
            g.mul(g.sawwave(130), 0.3)];
  },
  
  sqrwave: function(g)
  {
    return g.mul(g.sqrwave(330), 0.3);
  },

  sqrwave2: function(g)
  {
    return [g.mul(g.sqrwave(330), 0.3),
            g.mul(g.sqrwave(325), 0.3)];
  },
  
  triwave: function(g)
  {
    return g.mul(g.triwave(330), 0.3);
  },

  triwave2: function(g)
  {
    return [g.mul(g.triwave(330), 0.3),
            g.mul(g.triwave(325), 0.3)];
  },

  manyCycles: function(g)
  {
    let size = 500;
    let baseFreq = 80;
    let out = g.cycle(baseFreq);
    for (let i = 0; i < size; i++) 
    {
      baseFreq *= 1.01;
      out = g.add(out, g.cycle(baseFreq));
    }
    // on MacMini3/Chrome, we get 45-55% render capacity
    console.log(`${size} oscillators, hi: ${Math.round(baseFreq)}Hz`);
    return g.mul(out, 1 / size);
  },

  sin220: function(g)
  {
    return g.mul(g.sin(g.mul(g.TWOPI, g.phasor(1220))), 1);
  },

  sinGlitch: function(g)
  {
    // pick a random freq once in a while
    let freq = g.sah(g.rand(0, 100, 2000), g.rand(42), .9999);
    // alias the "heck" out of it.
    let fg = g.mul(g.TWOPI * 1234567, freq);
    return g.mul(.1, g.sin(g.slide(fg, 1, 1)));
  },
  
  sinGlitchFilt: function(g)
  {
    // pick a random freq once in a while
    // let freq = 155; 
    let freq = g.sah(g.rand(0, 100, 200), g.rand(42), .9999);
    let fg = g.mul(g.TWOPI * 1234567, freq);
    const cutoff = 4000 * g.FREQ_TO_NYQ; // cutoff is 0-1, 0-nyquist
    const res = .90;
    const signal = g.mul(.1, g.sin(g.slide(fg, 1, 1))); 
    return g.svf(signal, cutoff, res);
  },
  
  lowpass: function(g)
  {
    let cutoffP = g.param(.5);
    let resP = g.param(.5);
    let result = g.svf(g.mul(g.noise(), .1), cutoffP, resP);
    
    let startcutoff = 50;
    let endcutoff = 7000;
    let cutoff = startcutoff;
    let res = .80;
    let done = false;
    
    let dotest = () =>
    {
      cutoffP.value = g.FREQ_TO_NYQ * cutoff;
      resP.value = res;
      console.log(`svf cutoff: ${cutoff.toFixed(2)}, re: ${res.toFixed(2)}`);
      cutoff *= 2;
      if (cutoff > endcutoff)
      {
        cutoff = startcutoff;
        res += .02;
      }
      if (res < .98)
      {
        setTimeout(() =>
        {
          if (!done) dotest();
        }, 200);
      }
    };
    dotest();
    // cancel for running via genishTestSynths.js
    setTimeout(() =>
    {
      done = true;
    }, 4950);
    return result;
  },

  cycle220: function(g)
  {
    return g.mul(g.cycle(220), .2);
  },

  AM: function(g)
  {
    let sineOsc = g.cycle(440); 
    let amplitudeLFO = g.add(.1, g.mul(g.cycle(4), 0.1)); 
    return g.mul(sineOsc, amplitudeLFO);
  },

  FM: function(g)
  {
    let sineOsc = g.cycle(g.add(440, g.mul(10, g.cycle(1)))); 
    return g.mul(sineOsc, 1);
  },

  rand: function(g)
  {
    let freq = g.sah(g.rand(0, 120, 660), g.rand(42), .9995);
    return g.mul(g.cycle(freq), .2);
  },
  
  counter: function(g)
  {
    let freq = g.add(g.counter(.001, 0, 100), 100);
    return g.mul(g.cycle(freq), .2);
  },
  
  sliderand: function(g)
  {
    // sah(input, control, threshold);
    //   latch the input value when control > threshold.
    let freq = g.sah(g.rand(0, 120, 660), g.rand(42), .9995);
    let osc = g.mul(g.cycle(g.slide(freq, .05, .05)), .1);
    return osc;
  },
  
  ssd: function(g)
  {
    // we memoize g.sqrwave otherwise it runs twice.
    let sqr = g.memo(g.sqrwave(200));
    return g.mul(g.sub(g.ssd(sqr), sqr), .25);
  },
  
  ssd2: function(g)
  {
    let ssd = g.ssd();
    let sqr = g.memo(g.sqrwave(200));
    ssd.in(sqr);
    return g.mul(g.sub(ssd.out, sqr), .25);
  },
  
  delay: function(g)
  {
    let a = g.mul(.2, g.sqrwave(200));
    const dsamps = 100;
    const maxdelay = 3 * dsamps;
    let damt = g.madd(g.cycle(3), dsamps, 2 * dsamps);
    let delay = g.delay(a, damt, maxdelay);
    return [a, delay];
  },
  
  pingpong: function(g)
  {
    // frequencing to loop through
    let frequencies = g.data([220, 330, 440, 880]);
    // get non-interpolating signal for frequency
    // frequency passed to phasor controls note rate.
    let freqSignal = g.peek(frequencies, g.phasor(2), 'none'); 
    // create a decay envelope
    let envelope = g.sub(1, g.phasor(2));
    // multiply sine osc by envelope
    let notes = g.mul(g.cycle(freqSignal), envelope);
    // turn notes down and store result via memo()
    // so that it is only calculated once per
    // sample; the result can be used in multiple
    // spots throughout the graph. here it's used
    // in the delay and also is directly passed to
    // play.
    let gain = g.memo(g.mul(notes, .25));
    // create 1/4 second echo
    const delaysamps = .25 * g.SRATE;
    const maxdelay = delaysamps * 2;
    let echo = g.delay(gain, delaysamps, maxdelay);
    // passing an array to play creates a stereo signal
    // notes on the left, echos on the right
    // use 64-bit memory storage for improved timing
    return [gain, echo];
  },
  
  delayWow: function(g)
  {
    let freq = g.sah(g.rand(0, 120, 660), g.rand(42), .9995);
 
    // create an oscillator and scale its output
    let osc = g.mul(g.cycle(g.slide(freq, .05, .05)), .1);
    
    // create a single-sample delay
    let feedback = g.ssd();
 
    // feed our oscillator and our ssd into a .5s delay 
    const delaySamps = .5 * g.SRATE;
    let echo = g.delay(g.add(osc, feedback.out), 
                    delaySamps, 2 * delaySamps/*max*/);
 
    // control the mix between feedback and echo; this 
    // also dampens the feedback.
    let mixer = g.mix(echo, feedback.out, .9);

    // record output of mixer to process next sample
    feedback.in(mixer);
 
    return mixer;
  },

  noise: function(g)
  {
    return g.mul(g.noise(), .1);
  },
  
  mouseSine: function(g)
  {
    console.log("MouseX in window:/m ");
    let mouseX = g.param(330);
    let sineOsc = g.cycle(mouseX);
    
    globalThis.onmousemove = function(e) 
    { 
      // scale and offset in mousemove callback so we're not doing
      // it every sample.
      let freq = 20 + (e.clientX / window.innerWidth) * 8000;
      mouseX.value = freq;
      console.log(`freq:${freq.toFixed(1)}`);
    };

    setTimeout(() => 
    {
      console.log("mouseSine uninstalling mouse handler");
      globalThis.onmousemove = null; 
    }, globalThis.genishTimeout ?? 5000);
    return sineOsc;
  },

  param: function(g)
  {
    console.log("move your mouse in the sandbox window.");
    let frequency = g.param(330);
    let mouseY = frequency;
    let mouseX = g.param(15);
    // move from one frequency to the next logarithmically
    // over .02 sec (20ms), both down and up.
    let portamento = g.slide(frequency, .02, .02);
    // create an lfo for frequency modulation; base depth 
    // off mouseX
    let lfo = g.mul(g.cycle(5), mouseX);
 
    // add vibrato
    let vibrato = g.add(portamento, lfo);

    let result = g.mul(g.cycle(vibrato), .15);
 
    globalThis.onmousemove = function(e) 
    { 
      // scale and offset in mousemove callback so we're not doing
      // it every sample.
      mouseY.value = 990 - (e.clientY / window.innerHeight) * 880;
      mouseX.value = (e.clientX / window.innerWidth) * 100;
    };

    setTimeout(() => 
    {
      console.log("param test uninstalling mouse handler");
      globalThis.onmousemove = null; 
    }, 5000);
    return result;
  },

  amendefault: `
  function(g)
  {
    return g.data(${amenref})
    .then(d => 
    {
      return g.mul(g.peek(d, g.phasor(1)), .25); 
    });
  }`,

  amenfloor: `
  function(g)
  {
    return g.data(${amenref})
    .then(d => 
    {
      // get a randomized playback rate via sah. Tne value will be used
      // to drive a phasor index into peek; this means the value will be
      // in Hz. That is, a value of .25 means the entire sample,
      // irrespective of length, will be played in four seconds.
      let randsig = g.sah(g.mul(g.rand(), .25), g.rand(11), .985);
      return g.mul(g.peek(d, g.phasor(randsig), "floor"), .25); 
    });
  }`,

  amenlinear: `
  function(g)
  {
    return g.data(${amenref})
    .then(d => 
    {
      // get a randomized playback rate via sah. Tne value will be used
      // to drive a phasor index into peek; this means the value will be
      // in Hz. That is, a value of .25 means the entire sample,
      // irrespective of length, will be played in four seconds.
      let randsig = g.sah(g.mul(g.rand(), .25), g.rand(11), .99995);
      return g.mul(g.peek(d, g.phasor(randsig), "linear"), .25); 
    });
  }`,

  amencubic: `
  function(g)
  {
    return g.data(${amenref})
    .then(d => 
    {
      // get a randomized playback rate via sah. Tne value will be used
      // to drive a phasor index into peek; this means the value will be
      // in Hz. That is, a value of .25 means the entire sample,
      // irrespective of length, will be played in four seconds.
      let randsig = g.sah(g.mul(g.rand(), .25), g.rand(11), .99995);
      return g.mul(g.peek(d, g.phasor(randsig), "cubic"), .25); 
    });
  }`,

  amen2: `
  function(g)
  {
    return g.data(${amenref})
    .then(d => 
    {
      // get a randomized playback rate via sah. Tne value will be used
      // to drive a phasor index into peek; this means the value will be
      // in Hz. That is, a value of .25 means the entire sample,
      // irrespective of length, will be played in four seconds.
      let randsig = g.sah(g.mul(g.rand(), .25), g.rand(11), .99995);
      return [g.mul(g.peek(d, g.phasor(randsig)), .25), 
              g.peek(d, g.phasor(g.add(randsig, .2)))]; 
    });
  }`,

  amenslice: `
  function(g)
  {
    return g.data(${amenref})
    .then(d => 
    {
      // larger numSlices values result in smaller slices 
      let numSlices = 64;
      // measured in samples...
      let sliceLength = d.length / numSlices;
      // enable the 'speed' variable to be controlled externally.
      let speed = g.param(1.2);
      // create a random signal between 0 and numSlices-1)
      let random0_31 = g.floor(g.mul(g.abs(g.rand()), numSlices - 1));
      // count the number of samples played by the current slice. 
      let sliceCounter = g.counter(speed, 0, sliceLength);
      // After each sample sample random signal to pick a new slice to play
      let sliceNum = g.sah(random0_31, sliceCounter, sliceLength - 1);
      // get starting position, in samples, of current slice
      let start = g.mul(sliceNum, sliceLength);
      // add the current sliceCounter position to start to get the buffer index to read
      let read = g.peek(d, g.add(start, sliceCounter), 'linear', 'samples');
      return read;
    });
  }`,

  sah: function(g)
  {
    // create random signal between 220 and 440
    let random220_440 = g.add(220, g.mul(g.rand(), 220));
 
    // create a sample-and-hold that will sample our random frequency
    // whenever another random signal (in the range of 0-1) crosses a
    // high threshold. This will create a periodically changing frequency.
    // make sure to use different a seed for each call to rand() unless
    // you want them to output the same number stream
    let frequency = g.sah(random220_440, g.rand(2), .9999);
    
    // sine oscillator
    return g.mul(g.cycle(frequency), .1);
  },  

  peeklerp: function(g)
  {
    // create a data set of four values to loop through
    let d = g.data([440, 880, 220, 330]);
    // interpolate through data set over ten seconds 
    let freq = g.peek(d, g.phasor(.1, 0), 'linear');
    return g.mul(g.cycle(freq), .1);
  },

  peekfloor: function(g)
  {
    let d = g.data([220, 330, 440, 880]);
    // create a ramp over 10 seconds
    let freq = g.peek(d, g.phasor(.1), 'none');
    return  g.mul(g.cycle(freq), .1);
  },

  peekfloor_accel: function(g)
  {
    let d = g.data([220, 330, 440, 880]);
    // create a ramp from 0-4 over 10 seconds
    let acceleration = g.mul(g.phasor(.1), 4);
    // accelerate looking through our graph; don't use interpolation
    let freq = g.peek(d, g.phasor(acceleration), 'none') ;
    return  g.mul(g.cycle(freq), .1);
  },

  envLevels: function(g)
  {
    let trigger = g.bang();
    let env = g.data([0, .8, .4, .8, 0]);
    // ltp == less-than, pass, so return accum while it's less than 1
    //   second param of accum is reset
    let envp = g.peek(env, g.ltp(g.accum(.00001, trigger, 0, Infinity, 1), 1));
    let counter = 0;
    let doit = () =>
    {
      if (counter < 10)
      {
        setTimeout(() =>
        {
            console.log("trigger");
            trigger.trigger();
            counter++;
            doit();        
        }, 200);
      }
    };
    doit();
    return g.mul(g.cycle(330), envp);
  },

  ad: function(g)
  {
    let env = g.ad(.15, .15, .2);
    console.log("ad trigger (no release needed)");
    for (let i = 0;i < 5;i++)
    {
      setTimeout(() =>
      {
        env.trigger();
      }, 1000 + i * 400);
    }
    return g.mul(g.noise(), env);
  },

  cheapkick: function(g)
  {
    /* potential improvement:
        Sine oscillator
              |
        Pitch envelope
              |
        Amplitude envelope
              |
              +-------------+
                            |
        Filtered noise -----+
        Noise envelope      |
                        Soft clip
                            |
                        EQ/output
      with: pitch decay of 20-35ms, noise decay of 3-8ms,
         noise filter 3-5kHz
    */
    let fenv = g.ad(.001, .40, 1);
    let freq = g.mix(40, 160, fenv); // fenv deays from 1
    let env = g.ad(.001, 2.40, .65);
    for (let i = 0;i < 10;i++)
    {
      setTimeout(() =>
      {
        fenv.trigger();
        env.trigger();
      }, 2000 + i * 400);
    }
    return g.mul(g.cycle(freq), env);
  },

  adsr: function(g)
  {
    let env = g.adsr(.25, .1, .8, 1);
    setTimeout(() =>
    {
      console.log("adsr trigger");
      env.trigger();
    }, 500);
    setTimeout(() =>
    {
      console.log("adsr release");
      env.release();
    }, 2000);
    return g.mul3(g.cycle(220), env, .5);
  },

  adsrRetrigger: function(g)
  {
    let env = g.adsr(.25, .1, .8, 1);
    setTimeout(() =>
    {
      console.log("adsr trigger");
      env.trigger();
    }, 500);
    setTimeout(() =>
    {
      console.log("adsr retrigger");
      env.trigger();
    }, 1500);
    setTimeout(() =>
    {
      console.log("adsr release");
      env.release();
    }, 2000);
    return g.mul3(g.cycle(220), env, .5);
  },

  adsrWhen: function(g)
  {
    let env = g.adsr(.25, .2, .8, 1);
    // debugger;
    env.triggerWhen(-1.5);
    //env.releaseWhen(-3.0);
    //env.triggerWhen(-2.75); // interrupt release
    env.releaseWhen(-5);
    return g.mul3(g.cycle(220), env, .5);
  },

};
