exports.examples =
{
  passthrough: function(g)
  {
    return [g.in1, g.in2];
  },
  
  ampcrush: function(g)
  {
    function crusher(input, ampScale = 12)
    {
      return g.div(g.round(g.mul(input, ampScale)), ampScale);
    }
    return [crusher(g.in1), crusher(g.in2)];
  },
  
  timecrush: function(g)
  {
    function crusher(input, timeScale = 1800)
    {
      return g.sah(input, g.phasor(timeScale), .5);
    }
    return [crusher(g.in1), crusher(g.in2)];
  },
  
  comb: function(g)
  {
    let d = g.param(4800, "Delay", {min:10, max:8000, delta: 10, default: 4000});
    let wet = g.param(1, "Wet", {default: 1});
    let fb = g.param(.5, "Feedback", {default:.5});
    let ssd = g.ssd();
    let delay = g.delay(ssd.out, d, 8000);
    let out = g.add(g.in1, g.mul(fb, delay));
    ssd.in(out);
    return g.mix(g.in1, ssd, wet);
  },
};