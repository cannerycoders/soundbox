//
// An example of Hz.Recorder in interactive control mode.
// Make sure to press Arm to enable recording. Then record 
// and pause to select snippets of the performance.
//
// This example auditions notes from every builtin bank+patch.
//
let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let recorder = await scene.NewAnode("Hz.Recorder", {
  preset: {prefix: "rec2"}
});
recorder.Show();

let inst = await scene.NewAnode("Hz.FM7");
inst.Show();

let rev = await scene.NewAnode("Hz.Freeverb");
rev.Show();

let scope;
scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(inst, scope, rev, recorder, dac);
scene.VisualizeGraph();

let latency = scene.Seconds(.5);
let start = scene.Now() + latency;
let interval = scene.Seconds(0.2);
let legato = .5;
let nnotes = 20;
let nprogs = 32;
inst.SetParam("Bank", 1);
for (let p = 0;p < nprogs;p++)
{
  console.log(` patch select ${p}`);
  inst.SetParam("Patch", p, -1, start);
  let kbase = 50 + Math.floor(20 * Math.random());
  for (let i = 0;i < nnotes;i++)
  {
    let key = kbase + (i % 12);
    let vel = .7 + .3 * Math.random();
    inst.Note({key, velocity:vel, dur:legato * interval, when:start});
    start += interval;
    await scene.Wait(.9 * interval);
   yield; // allow cancellation of this fiber.
  }
}
await scene.Wait(scene.Seconds(2));
console.log("done");