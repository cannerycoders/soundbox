let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let defInst = {kit: "FatBoy", inst: "church_organ"};
let instrument;
instrument = (await SfLoader.RandomInstrument()) ?? defInst;
if(instrument.kit == "Tabla") instrument = defInst; // doesn't understand notes
let samplo = await scene.NewAnode("Hz.Samplo", { 
  preset: {
    A: 0.1, // soundfonts have a natural attack env.
    D: 0.01,
    S: 1,
    R: 1.5, // user releases prior to end of sbuf.
    Gain: 2,
  }
});
samplo.Show();
scene.Chain(samplo, dac);

let instref = `${instrument.kit}/${instrument.inst}`;
await samplo.LoadPreset({instrument});
let latency = scene.Seconds(.5);
let start = scene.Now() + latency;
let interval = scene.Seconds(.25);
let legato = 1;
let nnotes = 12 * 40;
let kbase = 40 + Math.floor(40 * Math.random());
console.log(`start ${instref} on ${kbase}`);
for(let i=0;i<nnotes;i++)
{
  // occasionally load a random voice instrument.
  if(i != 0 && (i % 12) == 0)
  {
    let instrument;
    if(Math.random() < .5)
      instrument = (await VCSLLoader.RandomInstrument()) ?? defInst;
    else
    {
      instrument = (await SfLoader.RandomInstrument()) ?? defInst;
        if(instrument.kit == "Tabla") instrument = defInst;
    }
    await samplo.LoadPreset({instrument});
    start += interval;
    instref = `${instrument.kit}/${instrument.inst}`; 
    kbase = 40 + Math.floor(40 * Math.random());
    console.log(`start ${instref} on ${kbase}`);
  }
  let key = kbase + (i%12);
  let vel = 1;
  let now = scene.Now();
  if(start < now)
  {
    console.warn("load-time lag " + (now - start).toFixed(2));
    start = now + scene.Seconds(.5);
  }
  // note with duration
  samplo.Note({key, velocity:vel, dur:legato*interval, when:start});
  await scene.Wait(interval);
  start += interval;
  yield; // allows this fiber to be cancelled.
}
await scene.Wait(scene.Seconds(2));
console.log("done");