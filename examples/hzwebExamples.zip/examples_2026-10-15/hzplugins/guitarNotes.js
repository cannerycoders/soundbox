let scene = await Ascene.BeginFiber(this);
let dac = scene.GetDAC();
dac.Show();

let inst = await scene.NewAnode("Hz.Guitar");
inst.Show();

let effects = await scene.NewAnode("Hz.Effects");
effects.Show();

let scope;
scope = await scene.NewAnode("Hz.Scope");
scope.Show();
scene.Chain(inst, scope, effects, dac);

let legato = .5;
let interval = scene.Seconds(.35);
let start = scene.Now();

const scaleNm = "C whole tone";
let keys = MusicTheory.GetScaleKeys(scaleNm, 2, 4).filter((k) => k > 38);
for (let i = 0;i < 1200;i++)
{
  if(i % 100 == 0)
  {
    const chordDur = scene.Seconds(.35);
    for(let j=0;j<4;j++)
    {
      const chord = MusicTheory.GetScaleChordKeys(scaleNm, j % 4, 4);
      inst.Chord(chord, .75, chordDur, start); // nb: chord != strum.
      await scene.Wait(chordDur * .99);
      start += 1.1 * chordDur;
    }
    start += chordDur*2;
    await scene.Wait(chordDur * 1.99);
  }
  let key = Random.Choose(keys);
  let vel = Random.InRange(.3, 1);
  inst.Note({key, velocity:vel, dur:interval, when:start});
  start += interval * legato;
  await scene.Wait(interval*legato*.99);
  yield;
}
