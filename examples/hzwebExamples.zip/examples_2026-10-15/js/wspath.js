console.log("wscwd: " + this.GetCWD());
console.log("wsfileref: " +  this.WSFileRef("../plug/foo.js"));