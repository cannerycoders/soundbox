let x = await Require("../req2.js");
exports.default = () => "under/" + x.default();