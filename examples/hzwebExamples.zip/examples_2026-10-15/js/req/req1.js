let x = await Require("./sub/under.js");
exports.world = function()
{
  return x.default() + "world";
};